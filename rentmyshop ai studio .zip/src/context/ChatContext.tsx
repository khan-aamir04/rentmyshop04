/**
 * RentMyShop In-App Real-Time Chat Context
 * Manages conversations, message streams, seen receipts, and unread counts
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { ConversationModel, MessageModel, PropertyModel } from '../types';
import { useAuth } from './AuthContext';
import { firestoreInstance } from '../services/firebaseConfig';
import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  onSnapshot, 
  orderBy 
} from 'firebase/firestore';

interface ChatContextType {
  conversations: ConversationModel[];
  activeConversation: ConversationModel | null;
  activeMessages: MessageModel[];
  isTyping: boolean;
  totalUnreadCount: number;
  openOrCreateConversation: (property: PropertyModel) => string;
  selectConversation: (id: string) => void;
  sendMessage: (conversationId: string, text: string) => Promise<void>;
  markAsSeen: (conversationId: string) => void;
  deleteMessage: (messageId: string) => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();

  // Production state: starts EMPTY. No hardcoded or demo conversations.
  const [conversations, setConversations] = useState<ConversationModel[]>(() => {
    const saved = localStorage.getItem('rentmyshop_real_conversations');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return [];
  });

  const [messagesMap, setMessagesMap] = useState<Record<string, MessageModel[]>>(() => {
    const saved = localStorage.getItem('rentmyshop_real_messages');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') return parsed;
      } catch {}
    }
    return {};
  });

  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState<boolean>(false);

  // 1. Real-time Firestore Sync for Conversations
  useEffect(() => {
    if (!currentUser) {
      setConversations([]);
      return;
    }

    if (!firestoreInstance) return;

    const q = query(
      collection(firestoreInstance, 'conversations'),
      where('participants', 'array-contains', currentUser.uid)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const liveConvs: ConversationModel[] = [];
        snapshot.forEach((d) => {
          liveConvs.push({ id: d.id, ...d.data() } as ConversationModel);
        });
        setConversations(liveConvs);
        localStorage.setItem('rentmyshop_real_conversations', JSON.stringify(liveConvs));
      },
      (err) => {
        console.warn('[RentMyShop] Firestore conversations listener error:', err);
      }
    );

    return () => unsubscribe();
  }, [currentUser?.uid]);

  // 2. Real-time Firestore Sync for Messages in Active Conversation
  useEffect(() => {
    if (!activeConversationId || !firestoreInstance) return;

    const q = query(
      collection(firestoreInstance, 'messages'),
      where('conversationId', '==', activeConversationId)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const liveMsgs: MessageModel[] = [];
        snapshot.forEach((d) => {
          liveMsgs.push({ id: d.id, ...d.data() } as MessageModel);
        });
        // Sort chronologically
        liveMsgs.sort((a, b) => (a.id > b.id ? 1 : -1));
        setMessagesMap((prev) => {
          const next = { ...prev, [activeConversationId]: liveMsgs };
          localStorage.setItem('rentmyshop_real_messages', JSON.stringify(next));
          return next;
        });
      },
      (err) => {
        console.warn('[RentMyShop] Firestore messages listener error:', err);
      }
    );

    return () => unsubscribe();
  }, [activeConversationId]);

  const activeConversation = conversations.find((c) => c.id === activeConversationId) || null;
  const activeMessages = activeConversationId ? messagesMap[activeConversationId] || [] : [];

  const totalUnreadCount = conversations.reduce((sum, c) => sum + (c.unreadCount || 0), 0);

  const openOrCreateConversation = (property: PropertyModel): string => {
    if (!currentUser) return '';

    // Prevent chatting with self
    if (property.ownerId === currentUser.uid) {
      alert('You are the owner of this commercial property listing.');
      return '';
    }

    const existing = conversations.find(
      (c) => c.shopId === property.id && c.participants.includes(currentUser.uid)
    );

    if (existing) {
      setActiveConversationId(existing.id);
      markAsSeen(existing.id);
      return existing.id;
    }

    // Create new conversation
    const newConvId = `conv_${property.id}_${currentUser.uid}`;
    const newConv: ConversationModel = {
      id: newConvId,
      participants: [currentUser.uid, property.ownerId],
      participantNames: {
        [currentUser.uid]: currentUser.fullName,
        [property.ownerId]: property.ownerName,
      },
      participantAvatars: {
        [currentUser.uid]: currentUser.profileImage,
        [property.ownerId]: property.ownerImage || '',
      },
      lastMessage: `Inquired about "${property.title}"`,
      lastMessageTime: 'Just now',
      lastSender: currentUser.uid,
      unreadCount: 0,
      shopId: property.id,
      shopTitle: property.title,
      shopThumbnail: property.thumbnail,
      shopPrice: property.price,
      shopPurpose: property.purpose,
    };

    const initialMsg: MessageModel = {
      id: `msg_${Date.now()}`,
      conversationId: newConvId,
      senderId: currentUser.uid,
      receiverId: property.ownerId,
      message: `Hi ${property.ownerName}, I'm interested in viewing "${property.title}". Is it currently available for commercial lease inspection?`,
      messageType: 'text',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      seen: false,
      deleted: false,
    };

    if (firestoreInstance) {
      try {
        setDoc(doc(firestoreInstance, 'conversations', newConvId), newConv);
        setDoc(doc(firestoreInstance, 'messages', initialMsg.id), initialMsg);
      } catch (err) {
        console.warn('[RentMyShop] Error creating conversation in Firestore:', err);
      }
    }

    setConversations((prev) => {
      const updated = [newConv, ...prev.filter((c) => c.id !== newConvId)];
      localStorage.setItem('rentmyshop_real_conversations', JSON.stringify(updated));
      return updated;
    });

    setMessagesMap((prev) => {
      const next = { ...prev, [newConvId]: [initialMsg] };
      localStorage.setItem('rentmyshop_real_messages', JSON.stringify(next));
      return next;
    });

    setActiveConversationId(newConvId);
    return newConvId;
  };

  const selectConversation = (id: string) => {
    setActiveConversationId(id);
    markAsSeen(id);
  };

  const markAsSeen = async (conversationId: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === conversationId ? { ...c, unreadCount: 0 } : c))
    );
    setMessagesMap((prev) => {
      const list = prev[conversationId];
      if (!list) return prev;
      return {
        ...prev,
        [conversationId]: list.map((m) => ({ ...m, seen: true })),
      };
    });

    if (firestoreInstance) {
      try {
        await updateDoc(doc(firestoreInstance, 'conversations', conversationId), {
          unreadCount: 0,
        });
      } catch (e) {}
    }
  };

  const sendMessage = async (conversationId: string, text: string) => {
    if (!currentUser || !text.trim()) return;

    const conv = conversations.find((c) => c.id === conversationId);
    if (!conv) return;

    const receiverId = conv.participants.find((p) => p !== currentUser.uid) || 'owner';

    const newMsg: MessageModel = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      conversationId,
      senderId: currentUser.uid,
      receiverId,
      message: text.trim(),
      messageType: 'text',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      seen: false,
      deleted: false,
    };

    if (firestoreInstance) {
      try {
        await setDoc(doc(firestoreInstance, 'messages', newMsg.id), newMsg);
        await updateDoc(doc(firestoreInstance, 'conversations', conversationId), {
          lastMessage: text.trim(),
          lastMessageTime: 'Just now',
          lastSender: currentUser.uid,
          updatedAt: new Date().toISOString(),
        });

        // Send alert notification to receiver
        const notifId = `notif_${Date.now()}`;
        await setDoc(doc(firestoreInstance, 'notifications', notifId), {
          id: notifId,
          receiverId,
          title: `New message from ${currentUser.fullName}`,
          body: text.trim().length > 60 ? `${text.trim().substring(0, 60)}...` : text.trim(),
          type: 'chat',
          isRead: false,
          createdAt: new Date().toISOString(),
        });
      } catch (err) {
        console.warn('[RentMyShop] Firestore message sending error:', err);
      }
    }

    setMessagesMap((prev) => {
      const currentList = prev[conversationId] || [];
      const next = { ...prev, [conversationId]: [...currentList, newMsg] };
      localStorage.setItem('rentmyshop_real_messages', JSON.stringify(next));
      return next;
    });

    setConversations((prev) => {
      const updated = prev.map((c) =>
        c.id === conversationId
          ? {
              ...c,
              lastMessage: text.trim(),
              lastMessageTime: 'Just now',
              lastSender: currentUser.uid,
            }
          : c
      );
      localStorage.setItem('rentmyshop_real_conversations', JSON.stringify(updated));
      return updated;
    });
  };

  const deleteMessage = (messageId: string) => {
    if (!activeConversationId) return;
    setMessagesMap((prev) => {
      const next = {
        ...prev,
        [activeConversationId]: (prev[activeConversationId] || []).filter((m) => m.id !== messageId),
      };
      localStorage.setItem('rentmyshop_real_messages', JSON.stringify(next));
      return next;
    });
  };

  return (
    <ChatContext.Provider
      value={{
        conversations,
        activeConversation,
        activeMessages,
        isTyping,
        totalUnreadCount,
        openOrCreateConversation,
        selectConversation,
        sendMessage,
        markAsSeen,
        deleteMessage,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};

