/**
 * RentMyShop Property Marketplace Context
 * Handles listings, CRUD, search, filter criteria, favorites, and admin moderation
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  PropertyModel, 
  CategoryModel, 
  FilterState, 
  PropertyStatus, 
  ReportModel, 
  PropertyCategory 
} from '../types';
import { useAuth } from './AuthContext';
import { firestoreInstance } from '../services/firebaseConfig';
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  onSnapshot, 
  increment 
} from 'firebase/firestore';

const DEFAULT_FILTERS: FilterState = {
  purpose: 'all',
  category: 'all',
  city: 'all',
  minPrice: undefined,
  maxPrice: undefined,
  minArea: undefined,
  maxArea: undefined,
  facilities: [],
  sortBy: 'newest',
  status: 'active',
};

const BASE_CATEGORIES: Omit<CategoryModel, 'count'>[] = [
  { id: 'cat-1', name: 'Shops', iconName: 'Store', isActive: true, ordering: 1 },
  { id: 'cat-2', name: 'Offices', iconName: 'Building2', isActive: true, ordering: 2 },
  { id: 'cat-3', name: 'Warehouses', iconName: 'Warehouse', isActive: true, ordering: 3 },
  { id: 'cat-4', name: 'Commercial Plaza', iconName: 'Building', isActive: true, ordering: 4 },
  { id: 'cat-5', name: 'Kiosk', iconName: 'ShoppingBag', isActive: true, ordering: 5 },
  { id: 'cat-6', name: 'Commercial Plot', iconName: 'LandPlot', isActive: true, ordering: 6 },
];

interface PropertyContextType {
  properties: PropertyModel[];
  categories: CategoryModel[];
  favorites: string[]; // shop ids
  filterState: FilterState;
  searchQuery: string;
  selectedCity: string;
  selectedCategory: PropertyCategory | 'all';
  reports: ReportModel[];
  isLoading: boolean;
  setSearchQuery: (query: string) => void;
  setSelectedCity: (city: string) => void;
  setSelectedCategory: (cat: PropertyCategory | 'all') => void;
  applyFilters: (filters: Partial<FilterState>) => void;
  resetFilters: () => void;
  toggleFavorite: (shopId: string) => void;
  isFavorite: (shopId: string) => boolean;
  getPropertyById: (id: string) => PropertyModel | undefined;
  incrementViews: (id: string) => void;
  createListing: (propertyData: Omit<PropertyModel, 'id' | 'views' | 'favorites' | 'chatCount' | 'createdAt' | 'updatedAt' | 'isDeleted' | 'isFeatured' | 'isVerified'>) => Promise<PropertyModel>;
  updateListing: (id: string, updates: Partial<PropertyModel>) => Promise<void>;
  updateListingStatus: (id: string, status: PropertyStatus) => Promise<void>;
  deleteListing: (id: string) => Promise<void>;
  reportListing: (shopId: string, shopTitle: string, reason: string, description: string) => Promise<void>;
  resolveReport: (reportId: string, removeListing?: boolean) => Promise<void>;
  adminApproveListing: (id: string) => void;
  adminRejectListing: (id: string) => void;
  adminToggleVerify: (id: string) => void;
  adminToggleFeature: (id: string) => void;
  myListings: PropertyModel[];
  favoriteProperties: PropertyModel[];
  filteredProperties: PropertyModel[];
}

const PropertyContext = createContext<PropertyContextType | undefined>(undefined);

export const PropertyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();

  // Production state: starts EMPTY. No hardcoded or demo listings.
  const [properties, setProperties] = useState<PropertyModel[]>(() => {
    const saved = localStorage.getItem('rentmyshop_real_properties');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return [];
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    if (!currentUser) return [];
    const saved = localStorage.getItem(`rentmyshop_real_favs_${currentUser.uid}`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return [];
  });

  const [reports, setReports] = useState<ReportModel[]>(() => {
    const saved = localStorage.getItem('rentmyshop_real_reports');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return [];
  });

  const [filterState, setFilterState] = useState<FilterState>(DEFAULT_FILTERS);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCity, setSelectedCity] = useState<string>('All Cities');
  const [selectedCategory, setSelectedCategory] = useState<PropertyCategory | 'all'>('all');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Dynamic real categories computed from live listings
  const categories: CategoryModel[] = BASE_CATEGORIES.map((cat) => ({
    ...cat,
    count: properties.filter((p) => p.category === cat.name && !p.isDeleted && p.status === 'active').length,
  }));

  // 1. Real-time Firestore Sync for Listings
  useEffect(() => {
    if (!firestoreInstance) return;

    setIsLoading(true);
    const q = query(collection(firestoreInstance, 'shops'), where('isDeleted', '==', false));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const liveProps: PropertyModel[] = [];
        snapshot.forEach((d) => {
          liveProps.push({ id: d.id, ...d.data() } as PropertyModel);
        });
        setProperties(liveProps);
        localStorage.setItem('rentmyshop_real_properties', JSON.stringify(liveProps));
        setIsLoading(false);
      },
      (err) => {
        console.warn('[RentMyShop] Firestore shops listener warning:', err);
        setIsLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // 2. Real-time Firestore Sync for Favorites
  useEffect(() => {
    if (!currentUser) {
      setFavorites([]);
      return;
    }

    // Load cached favorites for this user
    const saved = localStorage.getItem(`rentmyshop_real_favs_${currentUser.uid}`);
    if (saved) {
      try {
        setFavorites(JSON.parse(saved));
      } catch {}
    }

    if (!firestoreInstance) return;

    const q = query(
      collection(firestoreInstance, 'favorites'),
      where('userId', '==', currentUser.uid)
    );
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const favShopIds: string[] = [];
        snapshot.forEach((d) => {
          const data = d.data();
          if (data.shopId) favShopIds.push(data.shopId);
        });
        setFavorites(favShopIds);
        localStorage.setItem(`rentmyshop_real_favs_${currentUser.uid}`, JSON.stringify(favShopIds));
      },
      (err) => {
        console.warn('[RentMyShop] Firestore favorites listener warning:', err);
      }
    );

    return () => unsubscribe();
  }, [currentUser?.uid]);

  // 3. Sync reports from Firestore
  useEffect(() => {
    if (!firestoreInstance) return;

    const q = query(collection(firestoreInstance, 'reports'));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const liveReports: ReportModel[] = [];
        snapshot.forEach((d) => {
          liveReports.push({ id: d.id, ...d.data() } as ReportModel);
        });
        setReports(liveReports);
        localStorage.setItem('rentmyshop_real_reports', JSON.stringify(liveReports));
      },
      (err) => {
        console.warn('[RentMyShop] Firestore reports listener warning:', err);
      }
    );

    return () => unsubscribe();
  }, []);

  const toggleFavorite = async (shopId: string) => {
    if (!currentUser) return;

    const exists = favorites.includes(shopId);
    const favDocId = `${currentUser.uid}_${shopId}`;

    if (firestoreInstance) {
      try {
        if (exists) {
          await deleteDoc(doc(firestoreInstance, 'favorites', favDocId));
          await updateDoc(doc(firestoreInstance, 'shops', shopId), {
            favorites: increment(-1),
          });
        } else {
          await setDoc(doc(firestoreInstance, 'favorites', favDocId), {
            userId: currentUser.uid,
            shopId,
            createdAt: new Date().toISOString(),
          });
          await updateDoc(doc(firestoreInstance, 'shops', shopId), {
            favorites: increment(1),
          });
        }
      } catch (err) {
        console.warn('[RentMyShop] Firestore toggle favorite err:', err);
      }
    }

    setFavorites((prev) => {
      const updated = exists ? prev.filter((id) => id !== shopId) : [...prev, shopId];
      localStorage.setItem(`rentmyshop_real_favs_${currentUser.uid}`, JSON.stringify(updated));
      return updated;
    });

    setProperties((props) =>
      props.map((p) => {
        if (p.id === shopId) {
          return {
            ...p,
            favorites: Math.max(0, p.favorites + (exists ? -1 : 1)),
          };
        }
        return p;
      })
    );
  };

  const isFavorite = (shopId: string) => favorites.includes(shopId);

  const getPropertyById = (id: string) => properties.find((p) => p.id === id);

  const incrementViews = async (id: string) => {
    if (firestoreInstance) {
      try {
        await updateDoc(doc(firestoreInstance, 'shops', id), {
          views: increment(1),
        });
      } catch (e) {}
    }
    setProperties((prev) =>
      prev.map((p) => (p.id === id ? { ...p, views: p.views + 1 } : p))
    );
  };

  const createListing = async (
    propertyData: Omit<PropertyModel, 'id' | 'views' | 'favorites' | 'chatCount' | 'createdAt' | 'updatedAt' | 'isDeleted' | 'isFeatured' | 'isVerified'>
  ): Promise<PropertyModel> => {
    setIsLoading(true);

    const propId = `shop_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newProperty: PropertyModel = {
      ...propertyData,
      id: propId,
      views: 0,
      favorites: 0,
      chatCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isDeleted: false,
      isFeatured: false,
      isVerified: true,
      status: 'active',
    };

    if (firestoreInstance) {
      try {
        await setDoc(doc(firestoreInstance, 'shops', propId), newProperty);
      } catch (err) {
        console.warn('[RentMyShop] Firestore create shop error:', err);
      }
    }

    setProperties((prev) => {
      const updated = [newProperty, ...prev.filter((p) => p.id !== propId)];
      localStorage.setItem('rentmyshop_real_properties', JSON.stringify(updated));
      return updated;
    });

    setIsLoading(false);
    return newProperty;
  };

  const updateListing = async (id: string, updates: Partial<PropertyModel>) => {
    setIsLoading(true);

    if (firestoreInstance) {
      try {
        await updateDoc(doc(firestoreInstance, 'shops', id), {
          ...updates,
          updatedAt: new Date().toISOString(),
        });
      } catch (err) {
        console.warn('[RentMyShop] Firestore update shop error:', err);
      }
    }

    setProperties((prev) => {
      const updated = prev.map((p) =>
        p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p
      );
      localStorage.setItem('rentmyshop_real_properties', JSON.stringify(updated));
      return updated;
    });

    setIsLoading(false);
  };

  const updateListingStatus = async (id: string, status: PropertyStatus) => {
    await updateListing(id, { status });
  };

  const deleteListing = async (id: string) => {
    // Soft delete: isDeleted = true, status = 'deleted'
    await updateListing(id, { isDeleted: true, status: 'deleted' });
  };

  const reportListing = async (shopId: string, shopTitle: string, reason: string, description: string) => {
    const reportId = `rep_${Date.now()}`;
    const newReport: ReportModel = {
      id: reportId,
      reporterId: currentUser?.uid || 'guest',
      reporterEmail: currentUser?.email || 'user@rentmyshop.com',
      shopId,
      shopTitle,
      reason,
      description,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    if (firestoreInstance) {
      try {
        await setDoc(doc(firestoreInstance, 'reports', reportId), newReport);
      } catch (e) {}
    }

    setReports((prev) => {
      const updated = [newReport, ...prev];
      localStorage.setItem('rentmyshop_real_reports', JSON.stringify(updated));
      return updated;
    });
  };

  const resolveReport = async (reportId: string, removeListing = false) => {
    const report = reports.find((r) => r.id === reportId);
    if (report && removeListing) {
      await deleteListing(report.shopId);
    }
    if (firestoreInstance) {
      try {
        await updateDoc(doc(firestoreInstance, 'reports', reportId), {
          status: 'resolved',
        });
      } catch (e) {}
    }
    setReports((prev) => {
      const updated = prev.map((r) => (r.id === reportId ? { ...r, status: 'resolved' as const } : r));
      localStorage.setItem('rentmyshop_real_reports', JSON.stringify(updated));
      return updated;
    });
  };

  const adminApproveListing = (id: string) => {
    updateListing(id, { status: 'active', isVerified: true });
  };

  const adminRejectListing = (id: string) => {
    updateListing(id, { status: 'paused' });
  };

  const adminToggleVerify = (id: string) => {
    const p = getPropertyById(id);
    if (p) {
      updateListing(id, { isVerified: !p.isVerified });
    }
  };

  const adminToggleFeature = (id: string) => {
    const p = getPropertyById(id);
    if (p) {
      updateListing(id, { isFeatured: !p.isFeatured });
    }
  };

  const applyFilters = (newFilters: Partial<FilterState>) => {
    setFilterState((prev) => ({ ...prev, ...newFilters }));
  };

  const resetFilters = () => {
    setFilterState(DEFAULT_FILTERS);
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedCity('All Cities');
  };

  // Derived lists linked strictly to currentUser.uid and real listings
  const myListings = properties.filter(
    (p) => !p.isDeleted && Boolean(currentUser?.uid) && p.ownerId === currentUser?.uid
  );

  const favoriteProperties = properties.filter(
    (p) => !p.isDeleted && favorites.includes(p.id)
  );

  const filteredProperties = properties.filter((p) => {
    if (p.isDeleted) return false;
    // Status filter (only show active in marketplace for visitors/buyers)
    if (filterState.status && filterState.status !== 'all' && p.status !== filterState.status) {
      return false;
    }
    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.address.toLowerCase().includes(q) ||
        p.city.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q);
      if (!match) return false;
    }
    // Category
    const activeCat = selectedCategory !== 'all' ? selectedCategory : filterState.category;
    if (activeCat && activeCat !== 'all' && p.category !== activeCat) {
      return false;
    }
    // Purpose (Rent/Sale)
    if (filterState.purpose && filterState.purpose !== 'all' && p.purpose !== filterState.purpose) {
      return false;
    }
    // City
    const activeCity = selectedCity !== 'All Cities' ? selectedCity : filterState.city;
    if (activeCity && activeCity !== 'all' && activeCity !== 'All Cities' && p.city.toLowerCase() !== activeCity.toLowerCase()) {
      return false;
    }
    // Price
    if (filterState.minPrice && p.price < filterState.minPrice) return false;
    if (filterState.maxPrice && p.price > filterState.maxPrice) return false;
    // Area
    if (filterState.minArea && p.area < filterState.minArea) return false;
    if (filterState.maxArea && p.area > filterState.maxArea) return false;
    // Facilities
    if (filterState.facilities && filterState.facilities.length > 0) {
      const hasAll = filterState.facilities.every((f) => p.facilities.includes(f));
      if (!hasAll) return false;
    }
    return true;
  }).sort((a, b) => {
    if (filterState.sortBy === 'price_low') return a.price - b.price;
    if (filterState.sortBy === 'price_high') return b.price - a.price;
    if (filterState.sortBy === 'oldest') return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(); // newest default
  });

  return (
    <PropertyContext.Provider
      value={{
        properties,
        categories,
        favorites,
        filterState,
        searchQuery,
        selectedCity,
        selectedCategory,
        reports,
        isLoading,
        setSearchQuery,
        setSelectedCity,
        setSelectedCategory,
        applyFilters,
        resetFilters,
        toggleFavorite,
        isFavorite,
        getPropertyById,
        incrementViews,
        createListing,
        updateListing,
        updateListingStatus,
        deleteListing,
        reportListing,
        resolveReport,
        adminApproveListing,
        adminRejectListing,
        adminToggleVerify,
        adminToggleFeature,
        myListings,
        favoriteProperties,
        filteredProperties,
      }}
    >
      {children}
    </PropertyContext.Provider>
  );
};

export const useProperties = () => {
  const context = useContext(PropertyContext);
  if (!context) {
    throw new Error('useProperties must be used within a PropertyProvider');
  }
  return context;
};

