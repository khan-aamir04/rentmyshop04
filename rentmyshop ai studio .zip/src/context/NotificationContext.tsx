/**
 * RentMyShop In-App & Push Notification Context
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { NotificationModel, NotificationType } from '../types';
import { useAuth } from './AuthContext';
import { firestoreInstance } from '../services/firebaseConfig';
import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  onSnapshot 
} from 'firebase/firestore';

interface NotificationContextType {
  notifications: NotificationModel[];
  unreadCount: number;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: string) => void;
  broadcastSystemNotification: (title: string, body: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();

  // Production state: starts EMPTY. No hardcoded or demo notifications.
  const [notifications, setNotifications] = useState<NotificationModel[]>(() => {
    const saved = localStorage.getItem('rentmyshop_real_notifications');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return [];
  });

  // Real-time Firestore Sync for Notifications
  useEffect(() => {
    if (!currentUser || !firestoreInstance) return;

    const q = query(
      collection(firestoreInstance, 'notifications'),
      where('receiverId', 'in', [currentUser.uid, 'all'])
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const liveNotifs: NotificationModel[] = [];
        snapshot.forEach((d) => {
          liveNotifs.push({ id: d.id, ...d.data() } as NotificationModel);
        });
        // Sort newest first
        liveNotifs.sort((a, b) => (a.id < b.id ? 1 : -1));
        setNotifications(liveNotifs);
        localStorage.setItem('rentmyshop_real_notifications', JSON.stringify(liveNotifs));
      },
      (err) => {
        console.warn('[RentMyShop] Firestore notifications listener error:', err);
      }
    );

    return () => unsubscribe();
  }, [currentUser?.uid]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const markAsRead = async (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
    if (firestoreInstance) {
      try {
        await updateDoc(doc(firestoreInstance, 'notifications', id), { isRead: true });
      } catch (e) {}
    }
    const updated = notifications.map((n) => (n.id === id ? { ...n, isRead: true } : n));
    localStorage.setItem('rentmyshop_real_notifications', JSON.stringify(updated));
  };

  const markAllAsRead = async () => {
    const updated = notifications.map((n) => ({ ...n, isRead: true }));
    setNotifications(updated);
    localStorage.setItem('rentmyshop_real_notifications', JSON.stringify(updated));
    const db = firestoreInstance;
    if (db) {
      notifications.forEach(async (n) => {
        if (!n.isRead) {
          try {
            await updateDoc(doc(db, 'notifications', n.id), { isRead: true });
          } catch (e) {}
        }
      });
    }
  };

  const deleteNotification = async (id: string) => {
    const updated = notifications.filter((n) => n.id !== id);
    setNotifications(updated);
    localStorage.setItem('rentmyshop_real_notifications', JSON.stringify(updated));
    if (firestoreInstance) {
      try {
        await deleteDoc(doc(firestoreInstance, 'notifications', id));
      } catch (e) {}
    }
  };

  const broadcastSystemNotification = async (title: string, body: string) => {
    const notifId = `notif_${Date.now()}`;
    const newNotif: NotificationModel = {
      id: notifId,
      receiverId: currentUser?.uid || 'all',
      title,
      body,
      type: 'system_announcement',
      isRead: false,
      createdAt: 'Just now',
    };

    if (firestoreInstance) {
      try {
        await setDoc(doc(firestoreInstance, 'notifications', notifId), newNotif);
      } catch (e) {}
    }

    setNotifications((prev) => {
      const next = [newNotif, ...prev];
      localStorage.setItem('rentmyshop_real_notifications', JSON.stringify(next));
      return next;
    });
  };

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        markAsRead,
        markAllAsRead,
        deleteNotification,
        broadcastSystemNotification,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

