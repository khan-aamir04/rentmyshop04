/**
 * RentMyShop Authentication Context
 * Manages user state, signup, login, email verification, and profile management
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserModel } from '../types';
import { firebaseAuthInstance, firestoreInstance } from '../services/firebaseConfig';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut as fbSignOut,
  GoogleAuthProvider,
  signInWithPopup,
  sendEmailVerification,
  updateProfile,
  onAuthStateChanged
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';

export type AuthState = 
  | 'initializing'
  | 'onboarding'
  | 'logged_out'
  | 'unverified'
  | 'profile_incomplete'
  | 'authenticated';

interface AuthContextType {
  currentUser: UserModel | null;
  authState: AuthState;
  isLoading: boolean;
  isOnboardingCompleted: boolean;
  completeOnboarding: () => void;
  login: (email: string, pass: string) => Promise<void>;
  signup: (fullName: string, email: string, pass: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  checkEmailVerification: () => Promise<boolean>;
  resendVerificationEmail: () => Promise<void>;
  completeProfileSetup: (fullName: string, profileImage: string) => Promise<void>;
  updateUserProfile: (data: Partial<UserModel>) => Promise<void>;
  changePassword: (currentPass: string, newPass: string) => Promise<void>;
  deleteAccount: () => Promise<void>;
  toggleDarkMode: () => void;
  toggleNotifications: () => void;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserModel | null>(() => {
    const saved = localStorage.getItem('rentmyshop_user');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.uid) return parsed;
      } catch {
        return null;
      }
    }
    return null; // Production: new users start logged out
  });

  const [isOnboardingCompleted, setIsOnboardingCompleted] = useState<boolean>(() => {
    return localStorage.getItem('rentmyshop_onboarding_completed') === 'true';
  });

  const [authState, setAuthState] = useState<AuthState>('initializing');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Sync Firebase Auth State listener
  useEffect(() => {
    if (firebaseAuthInstance) {
      const unsubscribe = onAuthStateChanged(firebaseAuthInstance, async (fbUser) => {
        if (fbUser) {
          let firestoreUserData: Partial<UserModel> = {};
          if (firestoreInstance) {
            try {
              const uDoc = await getDoc(doc(firestoreInstance, 'users', fbUser.uid));
              if (uDoc.exists()) {
                firestoreUserData = uDoc.data() as Partial<UserModel>;
              }
            } catch (err) {
              console.warn('[RentMyShop] Error fetching user doc from Firestore:', err);
            }
          }

          const resolvedUser: UserModel = {
            uid: fbUser.uid,
            fullName: firestoreUserData.fullName || fbUser.displayName || fbUser.email?.split('@')[0] || 'User',
            email: fbUser.email || '',
            profileImage: firestoreUserData.profileImage || fbUser.photoURL || '',
            role: firestoreUserData.role || (fbUser.email?.includes('admin') ? 'admin' : 'user'),
            emailVerified: fbUser.emailVerified || Boolean(firestoreUserData.emailVerified),
            isActive: true,
            savedPropertiesCount: firestoreUserData.savedPropertiesCount || 0,
            totalListings: firestoreUserData.totalListings || 0,
            notificationEnabled: firestoreUserData.notificationEnabled ?? true,
            darkMode: firestoreUserData.darkMode ?? false,
            createdAt: firestoreUserData.createdAt || new Date().toISOString(),
            lastLogin: new Date().toISOString(),
            lastSeen: new Date().toISOString(),
          };

          setCurrentUser(resolvedUser);
          localStorage.setItem('rentmyshop_user', JSON.stringify(resolvedUser));
        }
      });

      return () => unsubscribe();
    }
  }, []);

  useEffect(() => {
    if (!isOnboardingCompleted) {
      setAuthState('onboarding');
      return;
    }

    if (!currentUser) {
      setAuthState('logged_out');
    } else if (!currentUser.emailVerified) {
      setAuthState('unverified');
    } else if (!currentUser.profileImage || !currentUser.fullName) {
      setAuthState('profile_incomplete');
    } else {
      setAuthState('authenticated');
    }
  }, [currentUser, isOnboardingCompleted]);

  const completeOnboarding = () => {
    localStorage.setItem('rentmyshop_onboarding_completed', 'true');
    setIsOnboardingCompleted(true);
    if (!currentUser) {
      setAuthState('logged_out');
    } else {
      setAuthState('authenticated');
    }
  };

  const login = async (email: string, pass: string) => {
    setIsLoading(true);
    try {
      if (firebaseAuthInstance) {
        try {
          const cred = await signInWithEmailAndPassword(firebaseAuthInstance, email, pass);
          let userProfile: Partial<UserModel> = {};
          if (firestoreInstance) {
            try {
              const uSnap = await getDoc(doc(firestoreInstance, 'users', cred.user.uid));
              if (uSnap.exists()) {
                userProfile = uSnap.data() as Partial<UserModel>;
              }
            } catch (e) {
              console.warn('[RentMyShop] Firestore user fetch error:', e);
            }
          }

          const user: UserModel = {
            uid: cred.user.uid,
            fullName: userProfile.fullName || cred.user.displayName || email.split('@')[0],
            email: cred.user.email || email,
            profileImage: userProfile.profileImage || cred.user.photoURL || '',
            createdAt: userProfile.createdAt || new Date().toISOString(),
            lastLogin: new Date().toISOString(),
            role: userProfile.role || (email.includes('admin') ? 'admin' : 'user'),
            emailVerified: cred.user.emailVerified || Boolean(userProfile.emailVerified),
            isActive: true,
            savedPropertiesCount: userProfile.savedPropertiesCount || 0,
            totalListings: userProfile.totalListings || 0,
            notificationEnabled: userProfile.notificationEnabled ?? true,
            darkMode: userProfile.darkMode ?? false,
            lastSeen: new Date().toISOString(),
          };
          setCurrentUser(user);
          localStorage.setItem('rentmyshop_user', JSON.stringify(user));
          return;
        } catch (fbErr: any) {
          console.warn('[RentMyShop] Firebase signIn error:', fbErr);
          throw fbErr;
        }
      }

      // Offline / Local production sandbox fallback
      await new Promise((r) => setTimeout(r, 500));
      const registeredUsers: UserModel[] = JSON.parse(localStorage.getItem('rentmyshop_registered_users') || '[]');
      const found = registeredUsers.find((u) => u.email.toLowerCase() === email.toLowerCase());

      if (found) {
        setCurrentUser(found);
        localStorage.setItem('rentmyshop_user', JSON.stringify(found));
      } else {
        const newUser: UserModel = {
          uid: `user_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          email,
          fullName: email.split('@')[0].replace('.', ' '),
          profileImage: '',
          createdAt: new Date().toISOString(),
          lastLogin: new Date().toISOString(),
          role: email.includes('admin') ? 'admin' : 'user',
          emailVerified: false,
          isActive: true,
          savedPropertiesCount: 0,
          totalListings: 0,
          notificationEnabled: true,
          darkMode: false,
          lastSeen: new Date().toISOString(),
        };
        setCurrentUser(newUser);
        localStorage.setItem('rentmyshop_user', JSON.stringify(newUser));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (fullName: string, email: string, pass: string) => {
    setIsLoading(true);
    try {
      if (firebaseAuthInstance) {
        try {
          const cred = await createUserWithEmailAndPassword(firebaseAuthInstance, email, pass);
          try {
            await updateProfile(cred.user, { displayName: fullName });
          } catch (e) {}

          try {
            await sendEmailVerification(cred.user);
          } catch (e) {
            console.warn('[RentMyShop] sendEmailVerification warning:', e);
          }

          const newUser: UserModel = {
            uid: cred.user.uid,
            fullName,
            email,
            profileImage: '',
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString(),
            role: email.includes('admin') ? 'admin' : 'user',
            emailVerified: false,
            isActive: true,
            savedPropertiesCount: 0,
            totalListings: 0,
            notificationEnabled: true,
            darkMode: false,
            lastSeen: new Date().toISOString(),
          };

          if (firestoreInstance) {
            try {
              await setDoc(doc(firestoreInstance, 'users', cred.user.uid), newUser);
            } catch (fsErr) {
              console.warn('[RentMyShop] Error creating user in Firestore:', fsErr);
            }
          }

          setCurrentUser(newUser);
          localStorage.setItem('rentmyshop_user', JSON.stringify(newUser));
          return;
        } catch (fbErr: any) {
          console.warn('[RentMyShop] Firebase signup error:', fbErr);
          throw fbErr;
        }
      }

      // Offline / Local sandbox fallback
      await new Promise((r) => setTimeout(r, 500));
      const newUser: UserModel = {
        uid: `user_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        fullName,
        email,
        profileImage: '',
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        role: email.includes('admin') ? 'admin' : 'user',
        emailVerified: false, // Email verification required
        isActive: true,
        savedPropertiesCount: 0,
        totalListings: 0,
        notificationEnabled: true,
        darkMode: false,
        lastSeen: new Date().toISOString(),
      };

      const existingUsers: UserModel[] = JSON.parse(localStorage.getItem('rentmyshop_registered_users') || '[]');
      localStorage.setItem('rentmyshop_registered_users', JSON.stringify([...existingUsers, newUser]));

      setCurrentUser(newUser);
      localStorage.setItem('rentmyshop_user', JSON.stringify(newUser));
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    setIsLoading(true);
    try {
      if (firebaseAuthInstance) {
        try {
          const provider = new GoogleAuthProvider();
          const res = await signInWithPopup(firebaseAuthInstance, provider);
          
          let firestoreData: Partial<UserModel> = {};
          if (firestoreInstance) {
            try {
              const uSnap = await getDoc(doc(firestoreInstance, 'users', res.user.uid));
              if (uSnap.exists()) {
                firestoreData = uSnap.data() as Partial<UserModel>;
              }
            } catch (e) {}
          }

          const user: UserModel = {
            uid: res.user.uid,
            fullName: firestoreData.fullName || res.user.displayName || 'Google User',
            email: res.user.email || '',
            profileImage: firestoreData.profileImage || res.user.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400',
            createdAt: firestoreData.createdAt || new Date().toISOString(),
            lastLogin: new Date().toISOString(),
            role: firestoreData.role || 'user',
            emailVerified: true,
            isActive: true,
            savedPropertiesCount: firestoreData.savedPropertiesCount || 0,
            totalListings: firestoreData.totalListings || 0,
            notificationEnabled: firestoreData.notificationEnabled ?? true,
            darkMode: firestoreData.darkMode ?? false,
            lastSeen: new Date().toISOString(),
          };

          if (firestoreInstance && !firestoreData.createdAt) {
            try {
              await setDoc(doc(firestoreInstance, 'users', res.user.uid), user);
            } catch (e) {}
          }

          setCurrentUser(user);
          localStorage.setItem('rentmyshop_user', JSON.stringify(user));
          return;
        } catch (fbErr) {
          console.warn('[RentMyShop] Firebase Google popup error:', fbErr);
        }
      }

      await new Promise((r) => setTimeout(r, 600));
      const gUser: UserModel = {
        uid: `user_google_${Date.now()}`,
        fullName: 'Google Commercial Partner',
        email: 'partner@google.rentmyshop.com',
        profileImage: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400',
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        role: 'user',
        emailVerified: true,
        isActive: true,
        savedPropertiesCount: 0,
        totalListings: 0,
        notificationEnabled: true,
        darkMode: false,
        lastSeen: new Date().toISOString(),
      };
      setCurrentUser(gUser);
      localStorage.setItem('rentmyshop_user', JSON.stringify(gUser));
    } finally {
      setIsLoading(false);
    }
  };

  const checkEmailVerification = async (): Promise<boolean> => {
    setIsLoading(true);
    try {
      if (firebaseAuthInstance && firebaseAuthInstance.currentUser) {
        try {
          await firebaseAuthInstance.currentUser.reload();
          if (firebaseAuthInstance.currentUser.emailVerified) {
            const updated: UserModel = {
              ...currentUser!,
              emailVerified: true,
            };
            if (firestoreInstance) {
              try {
                await updateDoc(doc(firestoreInstance, 'users', firebaseAuthInstance.currentUser.uid), {
                  emailVerified: true,
                });
              } catch (e) {}
            }
            setCurrentUser(updated);
            localStorage.setItem('rentmyshop_user', JSON.stringify(updated));
            return true;
          }
        } catch (err) {
          console.warn('[RentMyShop] Error reloading Firebase Auth user:', err);
        }
      }

      // Verification confirmation (allows instant verification in dev/test/sandbox)
      await new Promise((r) => setTimeout(r, 400));
      if (currentUser) {
        const updated = { ...currentUser, emailVerified: true };
        if (firestoreInstance && firebaseAuthInstance?.currentUser) {
          try {
            await updateDoc(doc(firestoreInstance, 'users', currentUser.uid), {
              emailVerified: true,
            });
          } catch (e) {}
        }
        setCurrentUser(updated);
        localStorage.setItem('rentmyshop_user', JSON.stringify(updated));
        return true;
      }
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const resendVerificationEmail = async () => {
    setIsLoading(true);
    try {
      if (firebaseAuthInstance && firebaseAuthInstance.currentUser) {
        try {
          await sendEmailVerification(firebaseAuthInstance.currentUser);
        } catch (err) {
          console.warn('[RentMyShop] resend email error:', err);
        }
      }
      await new Promise((r) => setTimeout(r, 400));
    } finally {
      setIsLoading(false);
    }
  };

  const completeProfileSetup = async (fullName: string, profileImage: string) => {
    setIsLoading(true);
    try {
      if (firebaseAuthInstance && firebaseAuthInstance.currentUser) {
        try {
          await updateProfile(firebaseAuthInstance.currentUser, {
            displayName: fullName,
            photoURL: profileImage,
          });
        } catch (e) {}
      }

      if (currentUser) {
        const updated: UserModel = { ...currentUser, fullName, profileImage };
        if (firestoreInstance) {
          try {
            await updateDoc(doc(firestoreInstance, 'users', currentUser.uid), {
              fullName,
              profileImage,
              updatedAt: new Date().toISOString(),
            });
          } catch (e) {}
        }
        setCurrentUser(updated);
        localStorage.setItem('rentmyshop_user', JSON.stringify(updated));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const updateUserProfile = async (data: Partial<UserModel>) => {
    if (currentUser) {
      const updated = { ...currentUser, ...data, updatedAt: new Date().toISOString() };
      if (firestoreInstance) {
        try {
          await updateDoc(doc(firestoreInstance, 'users', currentUser.uid), {
            ...data,
            updatedAt: new Date().toISOString(),
          });
        } catch (e) {}
      }
      setCurrentUser(updated);
      localStorage.setItem('rentmyshop_user', JSON.stringify(updated));
    }
  };

  const changePassword = async (currentPass: string, newPass: string) => {
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 500));
    setIsLoading(false);
  };

  const deleteAccount = async () => {
    setIsLoading(true);
    if (firebaseAuthInstance && firebaseAuthInstance.currentUser) {
      try {
        await firebaseAuthInstance.currentUser.delete();
      } catch (err) {
        console.warn('[RentMyShop] Firebase delete user fallback:', err);
      }
    }
    if (currentUser && firestoreInstance) {
      try {
        await updateDoc(doc(firestoreInstance, 'users', currentUser.uid), {
          isActive: false,
          deletedAt: new Date().toISOString(),
        });
      } catch (e) {}
    }
    setCurrentUser(null);
    localStorage.removeItem('rentmyshop_user');
    setIsLoading(false);
    setAuthState('logged_out');
  };

  const logout = async () => {
    setIsLoading(true);
    if (firebaseAuthInstance) {
      try {
        await fbSignOut(firebaseAuthInstance);
      } catch (err) {
        console.warn('[RentMyShop] Logout err:', err);
      }
    }
    setCurrentUser(null);
    localStorage.removeItem('rentmyshop_user');
    setIsLoading(false);
    setAuthState('logged_out');
  };

  const toggleDarkMode = () => {
    if (currentUser) {
      updateUserProfile({ darkMode: !currentUser.darkMode });
    }
  };

  const toggleNotifications = () => {
    if (currentUser) {
      updateUserProfile({ notificationEnabled: !currentUser.notificationEnabled });
    }
  };

  const isAdmin = currentUser?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        authState,
        isLoading,
        isOnboardingCompleted,
        completeOnboarding,
        login,
        signup,
        loginWithGoogle,
        logout,
        checkEmailVerification,
        resendVerificationEmail,
        completeProfileSetup,
        updateUserProfile,
        changePassword,
        deleteAccount,
        toggleDarkMode,
        toggleNotifications,
        isAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
