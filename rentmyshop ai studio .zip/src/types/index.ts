/**
 * RentMyShop - Type Definitions
 * Complete domain models matching future Firestore architecture
 */

export type UserRole = 'user' | 'admin';

export interface UserModel {
  uid: string;
  fullName: string;
  email: string;
  profileImage: string;
  phone?: string;
  createdAt: string;
  lastLogin: string;
  role: UserRole;
  emailVerified: boolean;
  profileSetupCompleted?: boolean;
  isActive: boolean;
  savedPropertiesCount: number;
  totalListings: number;
  notificationEnabled: boolean;
  darkMode: boolean;
  lastSeen: string;
  updatedAt?: string;
}

export type PropertyPurpose = 'rent' | 'sale';

export type PropertyCategory = 
  | 'Shops' 
  | 'Offices' 
  | 'Warehouses' 
  | 'Commercial Plaza' 
  | 'Kiosk' 
  | 'Commercial Plot';

export type PropertyStatus = 
  | 'active' 
  | 'paused' 
  | 'rented' 
  | 'sold' 
  | 'deleted' 
  | 'pending';

export type FacilityType = 
  | 'Parking' 
  | 'Washroom' 
  | 'Electricity' 
  | 'Water' 
  | 'Security' 
  | 'Internet' 
  | 'Corner';

export interface PropertyModel {
  id: string;
  ownerId: string;
  ownerName: string;
  ownerImage?: string;
  title: string;
  description: string;
  purpose: PropertyPurpose;
  price: number;
  pricePeriod?: string; // e.g., '/month' or 'total'
  category: PropertyCategory;
  address: string;
  city: string;
  latitude: number;
  longitude: number;
  area: number; // in sq ft
  facilities: FacilityType[];
  images: string[];
  thumbnail: string;
  status: PropertyStatus;
  views: number;
  favorites: number;
  chatCount: number;
  createdAt: string;
  updatedAt: string;
  isFeatured: boolean;
  isVerified: boolean;
  isDeleted: boolean;
}

export interface FavoriteModel {
  id: string;
  userId: string;
  shopId: string;
  createdAt: string;
}

export interface ConversationModel {
  id: string;
  participants: string[];
  participantNames?: Record<string, string>;
  participantAvatars?: Record<string, string>;
  participantImages?: Record<string, string>;
  lastMessage: string;
  lastMessageTime: string;
  lastMessageTimestamp?: string;
  lastSender: string;
  unreadCount: number;
  shopId: string;
  shopTitle: string;
  shopThumbnail: string;
  shopPrice: number;
  shopPurpose: PropertyPurpose;
  propertyId?: string;
  propertyTitle?: string;
  propertyThumbnail?: string;
  propertyPrice?: number;
}

export interface MessageModel {
  id: string;
  conversationId: string;
  senderId: string;
  receiverId: string;
  message: string;
  text?: string;
  messageType: 'text' | 'image';
  timestamp: string;
  seen: boolean;
  deleted: boolean;
}

export type NotificationType = 
  | 'new_message' 
  | 'property_approved' 
  | 'property_removed' 
  | 'property_updated' 
  | 'favorite_added' 
  | 'system_announcement';

export interface NotificationModel {
  id: string;
  receiverId: string;
  title: string;
  body: string;
  message?: string;
  type: NotificationType | string;
  relatedId?: string; // shopId or conversationId
  isRead: boolean;
  read?: boolean;
  createdAt: string;
}

export interface ReportModel {
  id: string;
  reporterId: string;
  reporterEmail: string;
  shopId: string;
  shopTitle: string;
  propertyTitle?: string;
  reason: string;
  description: string;
  details?: string;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
}

export interface CategoryModel {
  id: string;
  name: PropertyCategory;
  iconName: string;
  isActive: boolean;
  ordering: number;
  count?: number;
}

export interface FilterState {
  purpose?: PropertyPurpose | 'all';
  category?: PropertyCategory | 'all';
  city?: string;
  minPrice?: number;
  maxPrice?: number;
  minArea?: number;
  maxArea?: number;
  facilities: FacilityType[];
  sortBy: 'newest' | 'oldest' | 'price_low' | 'price_high' | 'nearest';
  status?: PropertyStatus | 'all';
}
