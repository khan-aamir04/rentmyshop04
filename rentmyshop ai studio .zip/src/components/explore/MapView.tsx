/**
 * RentMyShop Map/List View Explorer Component
 * Interactive map representation with commercial pins and property preview
 */

import React, { useState } from 'react';
import { PropertyModel } from '../../types';
import { PropertyCard } from '../common/PropertyCard';
import { MapPin, Navigation, ExternalLink, X } from 'lucide-react';
import { LocationService } from '../../services/locationService';

interface MapViewProps {
  properties: PropertyModel[];
  onSelectProperty: (property: PropertyModel) => void;
}

export const MapView: React.FC<MapViewProps> = ({ properties, onSelectProperty }) => {
  const [activePinProperty, setActivePinProperty] = useState<PropertyModel | null>(
    properties.length > 0 ? properties[0] : null
  );

  return (
    <div className="relative w-full h-[calc(100vh-230px)] min-h-[420px] rounded-[24px] overflow-hidden border border-slate-200 bg-slate-100 flex flex-col shadow-inner">
      {/* Visual Map Canvas Representation */}
      <div className="relative w-full h-full bg-[#EBF2F7] overflow-hidden flex items-center justify-center select-none">
        {/* Abstract Map Roads & Grid Background */}
        <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#94a3b8_1px,transparent_1px)] [background-size:20px_20px]" />
        
        {/* Simulated Road Lines */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/3 left-0 right-0 h-4 bg-white border-y border-slate-300" />
          <div className="absolute top-2/3 left-0 right-0 h-6 bg-amber-100 border-y border-amber-300" />
          <div className="absolute top-0 bottom-0 left-1/4 w-5 bg-white border-x border-slate-300" />
          <div className="absolute top-0 bottom-0 left-2/3 w-6 bg-slate-200 border-x border-slate-300" />
        </div>

        {/* Commercial Property Map Markers */}
        <div className="absolute inset-0 p-8 flex flex-wrap items-center justify-around">
          {properties.slice(0, 8).map((prop, idx) => {
            const isSelected = activePinProperty?.id === prop.id;
            // Spread positions deterministically
            const leftPerc = 15 + ((idx * 27) % 70);
            const topPerc = 20 + ((idx * 31) % 60);

            return (
              <button
                key={prop.id}
                onClick={() => setActivePinProperty(prop)}
                style={{ position: 'absolute', left: `${leftPerc}%`, top: `${topPerc}%` }}
                className={`group -translate-x-1/2 -translate-y-1/2 flex flex-col items-center cursor-pointer transition-all duration-300 z-20 ${
                  isSelected ? 'scale-115 z-30' : 'hover:scale-110'
                }`}
              >
                {/* Price Pill Tag */}
                <div
                  className={`px-2.5 py-1 rounded-full text-xs font-extrabold shadow-lg flex items-center gap-1 transition-colors border ${
                    isSelected
                      ? 'bg-slate-900 text-white border-slate-900 ring-4 ring-[#FF6B00]/30'
                      : 'bg-[#FF6B00] text-white border-white/50 hover:bg-[#E55F00]'
                  }`}
                >
                  <span>
                    ${prop.price >= 1000 ? `${(prop.price / 1000).toFixed(0)}k` : prop.price}
                  </span>
                </div>

                {/* Pin Pointer */}
                <div
                  className={`w-2.5 h-2.5 rotate-45 -mt-1 shadow-xs transition-colors ${
                    isSelected ? 'bg-slate-900' : 'bg-[#FF6B00]'
                  }`}
                />
              </button>
            );
          })}
        </div>

        {/* Top Controls Overlay */}
        <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
          {activePinProperty && (
            <a
              href={LocationService.getGoogleMapsUrl(
                activePinProperty.latitude,
                activePinProperty.longitude,
                activePinProperty.title
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3.5 py-2 bg-white/95 backdrop-blur-md text-xs font-bold text-slate-800 rounded-full shadow-md hover:text-[#FF6B00] transition-colors border border-slate-100"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[#FF6B00]" />
              <span>Open in Google Maps</span>
            </a>
          )}
        </div>
      </div>

      {/* Bottom Floating Property Card Preview */}
      {activePinProperty && (
        <div className="absolute bottom-4 left-4 right-4 z-30 max-w-sm mx-auto animate-in slide-in-from-bottom-4 duration-200">
          <div className="relative">
            <button
              onClick={() => setActivePinProperty(null)}
              className="absolute -top-2 -right-2 z-40 w-7 h-7 rounded-full bg-slate-900 text-white flex items-center justify-center shadow-lg hover:bg-slate-800"
            >
              <X className="w-3.5 h-3.5" />
            </button>
            <PropertyCard
              property={activePinProperty}
              onClick={() => onSelectProperty(activePinProperty)}
            />
          </div>
        </div>
      )}
    </div>
  );
};
