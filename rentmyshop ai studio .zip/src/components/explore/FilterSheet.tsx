/**
 * RentMyShop Professional Filter Bottom Sheet
 * 24px top radius, full commercial filter criteria, reset & apply actions
 */

import React, { useState } from 'react';
import { useProperties } from '../../context/PropertyContext';
import { 
  X, 
  Check, 
  RotateCcw, 
  SlidersHorizontal,
  DollarSign,
  Maximize2
} from 'lucide-react';
import { PropertyPurpose, PropertyCategory, FacilityType, FilterState } from '../../types';
import { POPULAR_COMMERCIAL_CITIES } from '../../services/locationService';

interface FilterSheetProps {
  isOpen: boolean;
  onClose: () => void;
}

const CATEGORIES: PropertyCategory[] = [
  'Shops',
  'Offices',
  'Warehouses',
  'Commercial Plaza',
  'Kiosk',
  'Commercial Plot'
];

const ALL_FACILITIES: FacilityType[] = [
  'Parking',
  'Washroom',
  'Electricity',
  'Water',
  'Security',
  'Internet',
  'Corner'
];

export const FilterSheet: React.FC<FilterSheetProps> = ({ isOpen, onClose }) => {
  const { filterState, applyFilters, resetFilters } = useProperties();

  const [localPurpose, setLocalPurpose] = useState<PropertyPurpose | 'all'>(filterState.purpose || 'all');
  const [localCategory, setLocalCategory] = useState<PropertyCategory | 'all'>(filterState.category || 'all');
  const [localCity, setLocalCity] = useState<string>(filterState.city || 'all');
  const [minPrice, setMinPrice] = useState<string>(filterState.minPrice ? String(filterState.minPrice) : '');
  const [maxPrice, setMaxPrice] = useState<string>(filterState.maxPrice ? String(filterState.maxPrice) : '');
  const [minArea, setMinArea] = useState<string>(filterState.minArea ? String(filterState.minArea) : '');
  const [maxArea, setMaxArea] = useState<string>(filterState.maxArea ? String(filterState.maxArea) : '');
  const [localFacilities, setLocalFacilities] = useState<FacilityType[]>(filterState.facilities || []);
  const [sortBy, setSortBy] = useState<FilterState['sortBy']>(filterState.sortBy || 'newest');

  if (!isOpen) return null;

  const toggleFacility = (facility: FacilityType) => {
    setLocalFacilities((prev) =>
      prev.includes(facility) ? prev.filter((f) => f !== facility) : [...prev, facility]
    );
  };

  const handleApply = () => {
    applyFilters({
      purpose: localPurpose,
      category: localCategory,
      city: localCity,
      minPrice: minPrice ? Number(minPrice) : undefined,
      maxPrice: maxPrice ? Number(maxPrice) : undefined,
      minArea: minArea ? Number(minArea) : undefined,
      maxArea: maxArea ? Number(maxArea) : undefined,
      facilities: localFacilities,
      sortBy,
    });
    onClose();
  };

  const handleReset = () => {
    resetFilters();
    setLocalPurpose('all');
    setLocalCategory('all');
    setLocalCity('all');
    setMinPrice('');
    setMaxPrice('');
    setMinArea('');
    setMaxArea('');
    setLocalFacilities([]);
    setSortBy('newest');
    onClose();
  };

  // Count active filters
  let activeCount = 0;
  if (localPurpose !== 'all') activeCount++;
  if (localCategory !== 'all') activeCount++;
  if (localCity !== 'all') activeCount++;
  if (minPrice || maxPrice) activeCount++;
  if (minArea || maxArea) activeCount++;
  if (localFacilities.length > 0) activeCount += localFacilities.length;
  if (sortBy !== 'newest') activeCount++;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      <div 
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl max-h-[85vh] bg-white rounded-t-[24px] shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300"
      >
        {/* Sheet Drag Handle & Header */}
        <div className="pt-3 px-6 pb-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-5 h-5 text-[#FF6B00]" />
            <h2 className="text-lg font-bold text-slate-900">Commercial Filters</h2>
            {activeCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-[#FF6B00] text-white text-xs font-bold flex items-center justify-center">
                {activeCount}
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Filter Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-800">
          {/* Purpose: Rent vs Sale */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              Property Purpose
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['all', 'rent', 'sale'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setLocalPurpose(p)}
                  className={`py-2.5 rounded-[14px] text-xs font-bold capitalize transition-all border ${
                    localPurpose === p
                      ? 'bg-[#FF6B00] text-white border-[#FF6B00] shadow-sm shadow-[#FF6B00]/30'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {p === 'all' ? 'All (Rent & Sale)' : `For ${p}`}
                </button>
              ))}
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              Commercial Category
            </label>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setLocalCategory('all')}
                className={`px-3.5 py-2 rounded-[14px] text-xs font-semibold transition-all border ${
                  localCategory === 'all'
                    ? 'bg-[#FF6B00] text-white border-[#FF6B00]'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                All Categories
              </button>
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setLocalCategory(cat)}
                  className={`px-3.5 py-2 rounded-[14px] text-xs font-semibold transition-all border ${
                    localCategory === cat
                      ? 'bg-[#FF6B00] text-white border-[#FF6B00]'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              Price Range ($)
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div className="relative">
                <DollarSign className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="number"
                  placeholder="Min Price"
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold focus:bg-white focus:border-[#FF6B00] outline-hidden"
                />
              </div>
              <div className="relative">
                <DollarSign className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="number"
                  placeholder="Max Price"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold focus:bg-white focus:border-[#FF6B00] outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* Area Range */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              Area Range (sq ft)
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div className="relative">
                <Maximize2 className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="number"
                  placeholder="Min Sq Ft"
                  value={minArea}
                  onChange={(e) => setMinArea(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold focus:bg-white focus:border-[#FF6B00] outline-hidden"
                />
              </div>
              <div className="relative">
                <Maximize2 className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="number"
                  placeholder="Max Sq Ft"
                  value={maxArea}
                  onChange={(e) => setMaxArea(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold focus:bg-white focus:border-[#FF6B00] outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* City Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              City / Market
            </label>
            <select
              value={localCity}
              onChange={(e) => setLocalCity(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold focus:bg-white focus:border-[#FF6B00] outline-hidden"
            >
              <option value="all">All Cities</option>
              {POPULAR_COMMERCIAL_CITIES.map((c) => (
                <option key={c.city} value={c.city}>
                  {c.city}, {c.state}
                </option>
              ))}
            </select>
          </div>

          {/* Facilities Checkboxes */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              Required Commercial Facilities
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {ALL_FACILITIES.map((facility) => {
                const checked = localFacilities.includes(facility);
                return (
                  <button
                    key={facility}
                    type="button"
                    onClick={() => toggleFacility(facility)}
                    className={`flex items-center gap-2 p-2.5 rounded-[14px] text-xs font-medium border text-left transition-all ${
                      checked
                        ? 'bg-[#FFF5EE] border-[#FF6B00] text-[#FF6B00] font-bold'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-md flex items-center justify-center border transition-colors ${
                        checked
                          ? 'bg-[#FF6B00] border-[#FF6B00] text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {checked && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                    <span>{facility}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sort By */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              Sort Results By
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'newest', label: 'Newest Listed' },
                { id: 'oldest', label: 'Oldest' },
                { id: 'price_low', label: 'Price: Low to High' },
                { id: 'price_high', label: 'Price: High to Low' },
              ].map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setSortBy(s.id as FilterState['sortBy'])}
                  className={`p-2.5 rounded-[14px] text-xs font-medium border transition-all text-center ${
                    sortBy === s.id
                      ? 'bg-slate-900 text-white border-slate-900 font-bold'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/70 flex items-center gap-3">
          <button
            type="button"
            onClick={handleReset}
            className="flex-1 py-3 px-4 rounded-[14px] bg-white border border-slate-200 text-slate-700 text-xs font-bold flex items-center justify-center gap-2 hover:bg-slate-100 active:scale-95 transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Filters</span>
          </button>
          <button
            type="button"
            onClick={handleApply}
            className="flex-2 py-3 px-4 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold shadow-md shadow-[#FF6B00]/30 active:scale-95 transition-all"
          >
            Apply Filters {activeCount > 0 && `(${activeCount})`}
          </button>
        </div>
      </div>
    </div>
  );
};
