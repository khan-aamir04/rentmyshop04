/**
 * RentMyShop Skeletons & Loading States
 * Avoids blank white screens while content is loading
 */

import React from 'react';

export const PropertyCardSkeleton: React.FC<{ horizontal?: boolean }> = ({ horizontal = false }) => (
  <div 
    className={`bg-white rounded-[18px] border border-slate-100 overflow-hidden animate-pulse ${
      horizontal ? 'min-w-[280px] max-w-[320px]' : 'w-full'
    }`}
  >
    <div className="aspect-[16/10] w-full bg-slate-200" />
    <div className="p-4 space-y-3">
      <div className="flex justify-between items-center">
        <div className="h-6 w-24 bg-slate-200 rounded-md" />
        <div className="h-4 w-16 bg-slate-100 rounded-full" />
      </div>
      <div className="h-4 w-3/4 bg-slate-200 rounded-md" />
      <div className="h-3 w-1/2 bg-slate-100 rounded-md" />
      <div className="pt-3 border-t border-slate-100 flex justify-between">
        <div className="h-3 w-20 bg-slate-100 rounded-md" />
        <div className="h-3 w-12 bg-slate-100 rounded-md" />
      </div>
    </div>
  </div>
);

export const PropertyListSkeleton: React.FC<{ count?: number }> = ({ count = 4 }) => (
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
    {Array.from({ length: count }).map((_, i) => (
      <PropertyCardSkeleton key={i} />
    ))}
  </div>
);

export const ConversationSkeleton: React.FC = () => (
  <div className="flex items-center gap-3 p-3.5 bg-white rounded-[18px] border border-slate-100 animate-pulse">
    <div className="w-12 h-12 rounded-full bg-slate-200 shrink-0" />
    <div className="flex-1 space-y-2">
      <div className="flex justify-between">
        <div className="h-4 w-32 bg-slate-200 rounded-md" />
        <div className="h-3 w-10 bg-slate-100 rounded-md" />
      </div>
      <div className="h-3 w-48 bg-slate-100 rounded-md" />
    </div>
  </div>
);
