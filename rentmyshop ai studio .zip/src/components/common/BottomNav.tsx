/**
 * RentMyShop Main Shell Bottom Navigation Bar
 * Exactly 5 destinations: Home, Explore, Add Listing (prominent), Chats, Profile
 */

import React from 'react';
import { 
  Home, 
  Compass, 
  Plus, 
  MessageSquare, 
  User 
} from 'lucide-react';
import { useChat } from '../../context/ChatContext';

export type NavTab = 'home' | 'explore' | 'add_listing' | 'add' | 'chats' | 'profile';

export interface BottomNavProps {
  currentTab?: NavTab;
  activeTab?: NavTab;
  onTabChange: (tab: NavTab) => void;
  unreadChatsCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({ 
  currentTab, 
  activeTab, 
  onTabChange,
  unreadChatsCount 
}) => {
  const { totalUnreadCount: contextUnread } = useChat();
  const effectiveUnread = unreadChatsCount !== undefined ? unreadChatsCount : contextUnread;
  const tab = activeTab || currentTab || 'home';
  const isAdd = tab === 'add' || tab === 'add_listing';

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/80 safe-area-pb">
      <div className="max-w-md md:max-w-xl mx-auto px-4 h-16 flex items-center justify-around">
        {/* Home */}
        <button
          id="nav-tab-home"
          onClick={() => onTabChange('home')}
          className={`flex flex-col items-center justify-center gap-1 transition-colors relative py-1 px-3 active:scale-95 ${
            tab === 'home' ? 'text-[#FF6B00]' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Home className="w-5 h-5" strokeWidth={tab === 'home' ? 2.5 : 1.8} />
          <span className="text-[10px] font-bold">Home</span>
          {tab === 'home' && (
            <span className="absolute bottom-0 w-4 h-0.5 bg-[#FF6B00] rounded-full" />
          )}
        </button>

        {/* Explore */}
        <button
          id="nav-tab-explore"
          onClick={() => onTabChange('explore')}
          className={`flex flex-col items-center justify-center gap-1 transition-colors relative py-1 px-3 active:scale-95 ${
            tab === 'explore' ? 'text-[#FF6B00]' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Compass className="w-5 h-5" strokeWidth={tab === 'explore' ? 2.5 : 1.8} />
          <span className="text-[10px] font-bold">Explore</span>
          {tab === 'explore' && (
            <span className="absolute bottom-0 w-4 h-0.5 bg-[#FF6B00] rounded-full" />
          )}
        </button>

        {/* Add Listing - Prominent Center Action */}
        <button
          id="nav-tab-add-listing"
          onClick={() => onTabChange('add_listing')}
          aria-label="Add Property Listing"
          className="flex flex-col items-center justify-center group -mt-5 focus:outline-hidden"
        >
          <div className="w-12 h-12 rounded-full bg-[#FF6B00] text-white flex items-center justify-center shadow-lg shadow-[#FF6B00]/35 ring-4 ring-white group-hover:bg-[#E55F00] group-active:scale-90 transition-all duration-200">
            <Plus className="w-6 h-6 stroke-[2.5]" />
          </div>
          <span className={`text-[10px] font-bold mt-1 ${isAdd ? 'text-[#FF6B00]' : 'text-slate-500'}`}>
            Add
          </span>
        </button>

        {/* Chats */}
        <button
          id="nav-tab-chats"
          onClick={() => onTabChange('chats')}
          className={`flex flex-col items-center justify-center gap-1 transition-colors relative py-1 px-3 active:scale-95 ${
            tab === 'chats' ? 'text-[#FF6B00]' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <div className="relative">
            <MessageSquare className="w-5 h-5" strokeWidth={tab === 'chats' ? 2.5 : 1.8} />
            {effectiveUnread > 0 && (
              <span className="absolute -top-1 -right-2 min-w-[16px] h-4 px-1 rounded-full bg-[#FF6B00] text-white text-[9px] font-extrabold flex items-center justify-center ring-2 ring-white">
                {effectiveUnread}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold">Chats</span>
          {tab === 'chats' && (
            <span className="absolute bottom-0 w-4 h-0.5 bg-[#FF6B00] rounded-full" />
          )}
        </button>

        {/* Profile */}
        <button
          id="nav-tab-profile"
          onClick={() => onTabChange('profile')}
          className={`flex flex-col items-center justify-center gap-1 transition-colors relative py-1 px-3 active:scale-95 ${
            tab === 'profile' ? 'text-[#FF6B00]' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <User className="w-5 h-5" strokeWidth={tab === 'profile' ? 2.5 : 1.8} />
          <span className="text-[10px] font-bold">Profile</span>
          {tab === 'profile' && (
            <span className="absolute bottom-0 w-4 h-0.5 bg-[#FF6B00] rounded-full" />
          )}
        </button>
      </div>
    </nav>
  );
};
