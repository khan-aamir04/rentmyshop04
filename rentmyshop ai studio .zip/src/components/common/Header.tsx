/**
 * RentMyShop Application Header Component
 * Provides dynamic time-based greeting, location selector, notification badge, and search trigger
 */

import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';
import { useProperties } from '../../context/PropertyContext';
import { 
  Bell, 
  MapPin, 
  ChevronDown, 
  Search, 
  SlidersHorizontal, 
  Navigation, 
  Check,
  ArrowLeft
} from 'lucide-react';
import { POPULAR_COMMERCIAL_CITIES, LocationService } from '../../services/locationService';

export interface HeaderProps {
  title?: string;
  isNested?: boolean;
  onBack?: () => void;
  onOpenNotifications: () => void;
  onOpenProfile?: () => void;
  onOpenExploreWithSearch?: () => void;
  onOpenFilters?: () => void;
  notificationCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  isNested,
  onBack,
  onOpenNotifications,
  onOpenProfile,
  onOpenExploreWithSearch,
  onOpenFilters,
  notificationCount,
}) => {
  const { currentUser } = useAuth();
  const { unreadCount: contextUnread } = useNotifications();
  const effectiveUnread = notificationCount !== undefined ? notificationCount : contextUnread;
  const { selectedCity, setSelectedCity, searchQuery, setSearchQuery } = useProperties();

  const [showCityPicker, setShowCityPicker] = useState(false);
  const [isLocating, setIsLocating] = useState(false);

  // Dynamic greeting based on current local time
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const handleUseCurrentLocation = async () => {
    setIsLocating(true);
    try {
      const loc = await LocationService.getCurrentLocation();
      if (loc.city) {
        setSelectedCity(loc.city);
      }
    } finally {
      setIsLocating(false);
      setShowCityPicker(false);
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-100 px-4 pt-3 pb-3 transition-all">
      <div className="max-w-7xl mx-auto flex flex-col gap-3">
        {/* Top Row: Greeting, Location & Actions OR Nested Title Bar */}
        {isNested && title ? (
          <div className="flex items-center justify-between gap-3 h-10">
            <div className="flex items-center gap-3">
              {onBack && (
                <button
                  onClick={onBack}
                  className="w-10 h-10 rounded-full bg-slate-50 hover:bg-slate-100 border border-slate-200/80 flex items-center justify-center text-slate-700 active:scale-95 transition-all"
                  aria-label="Go back"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
              )}
              <h1 className="text-lg font-extrabold text-slate-900 tracking-tight">
                {title}
              </h1>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="notifications-nav-btn"
                onClick={onOpenNotifications}
                aria-label="Open notifications"
                className="relative w-10 h-10 rounded-[14px] bg-slate-50 border border-slate-200/80 flex items-center justify-center text-slate-700 hover:bg-slate-100 transition-colors active:scale-95"
              >
                <Bell className="w-5 h-5" />
                {effectiveUnread > 0 && (
                  <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-[#FF6B00] rounded-full ring-2 ring-white animate-pulse" />
                )}
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between gap-3">
            {/* Brand & Greeting */}
            <div className="flex items-center gap-3">
              <div 
                onClick={onOpenProfile}
                className="relative w-10 h-10 rounded-full ring-2 ring-[#FF6B00]/20 p-0.5 cursor-pointer active:scale-95 transition-transform"
              >
                <img
                  src={currentUser?.profileImage || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400'}
                  alt="Profile"
                  referrerPolicy="no-referrer"
                  className="w-full h-full rounded-full object-cover"
                />
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white" />
              </div>

              <div>
                <p className="text-xs font-semibold text-slate-400">
                  {getGreeting()}, {currentUser?.fullName?.split(' ')[0] || 'Partner'}
                </p>
                {/* Location Picker Trigger */}
                <div className="relative">
                  <button
                    id="header-location-picker-btn"
                    onClick={() => setShowCityPicker(!showCityPicker)}
                    className="flex items-center gap-1 text-sm font-bold text-slate-800 hover:text-[#FF6B00] transition-colors"
                  >
                    <MapPin className="w-3.5 h-3.5 text-[#FF6B00]" />
                    <span className="truncate max-w-[140px] sm:max-w-[200px]">{selectedCity}</span>
                    <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${showCityPicker ? 'rotate-180' : ''}`} />
                  </button>

                  {/* Dropdown City Menu */}
                  {showCityPicker && (
                    <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-[18px] shadow-2xl border border-slate-100 p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-200">
                      <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-3 py-1.5">
                        Commercial Markets
                      </p>

                      <button
                        onClick={handleUseCurrentLocation}
                        disabled={isLocating}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-[#FF6B00] hover:bg-[#FFF5EE] rounded-[10px] transition-colors mb-1"
                      >
                        <Navigation className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
                        <span>{isLocating ? 'Detecting Location...' : 'Use Current Location'}</span>
                      </button>

                      <button
                        onClick={() => {
                          setSelectedCity('All Cities');
                          setShowCityPicker(false);
                        }}
                        className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-[10px] transition-colors ${
                          selectedCity === 'All Cities'
                            ? 'bg-slate-100 text-slate-900 font-bold'
                            : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span>All Cities (Worldwide)</span>
                        {selectedCity === 'All Cities' && <Check className="w-3.5 h-3.5 text-[#FF6B00]" />}
                      </button>

                      {POPULAR_COMMERCIAL_CITIES.map((c) => (
                        <button
                          key={c.city}
                          onClick={() => {
                            setSelectedCity(c.city);
                            setShowCityPicker(false);
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-[10px] transition-colors ${
                            selectedCity === c.city
                              ? 'bg-slate-100 text-slate-900 font-bold'
                              : 'text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          <span>{c.city}, {c.state}</span>
                          {selectedCity === c.city && <Check className="w-3.5 h-3.5 text-[#FF6B00]" />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right Action: Notification Bell */}
            <div className="flex items-center gap-2">
              <button
                id="notifications-nav-btn"
                onClick={onOpenNotifications}
                aria-label="Open notifications"
                className="relative w-10 h-10 rounded-[14px] bg-slate-50 border border-slate-200/80 flex items-center justify-center text-slate-700 hover:bg-slate-100 transition-colors active:scale-95"
              >
                <Bell className="w-5 h-5" />
                {effectiveUnread > 0 && (
                  <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-[#FF6B00] rounded-full ring-2 ring-white animate-pulse" />
                )}
              </button>
            </div>
          </div>
        )}

        {/* Bottom Row: Prominent Search Input with Filter Trigger on Home/Explore */}
        {!isNested && (
          <div className="flex items-center gap-2">
            <div 
              onClick={onOpenExploreWithSearch}
              className="flex-1 relative flex items-center bg-slate-100/90 hover:bg-slate-100 rounded-[14px] px-3.5 py-2.5 transition-all cursor-pointer border border-transparent focus-within:border-[#FF6B00] focus-within:bg-white focus-within:ring-2 focus-within:ring-[#FF6B00]/10"
            >
              <Search className="w-4.5 h-4.5 text-slate-400 mr-2.5 shrink-0" />
              <input
                id="header-search-input"
                type="text"
                placeholder="Search shops, offices, warehouses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent text-sm text-slate-800 placeholder-slate-400 outline-hidden font-medium"
              />
            </div>

            {onOpenFilters && (
              <button
                id="header-filter-btn"
                onClick={onOpenFilters}
                aria-label="Filter properties"
                className="w-11 h-11 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white flex items-center justify-center shadow-md shadow-[#FF6B00]/20 active:scale-95 transition-all"
              >
                <SlidersHorizontal className="w-4.5 h-4.5" />
              </button>
            )}
          </div>
        )}
      </div>
    </header>
  );
};
