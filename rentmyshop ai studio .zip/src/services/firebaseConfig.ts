/**
 /**
 * RentMyShop Firebase Configuration & Service Bootstrap
 * Supports environment variables added via .env (VITE_FIREBASE_API_KEY, etc.)
 */

import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore } from 'firebase/firestore';

// Environment variables from client Vite
const firebaseConfig = {
  apiKey: "AIzaSyAacFV0yD0jPrH5DUw8lhS86JCNkVeyn7I",
  authDomain: "rentmyshop-ed18a.firebaseapp.com",
  projectId: "rentmyshop-ed18a",
  storageBucket: "rentmyshop-ed18a.firebasestorage.app",
  messagingSenderId: "68604637711",
  appId: "1:68604637711:web:b7d6c67aeb88d7e25ee97a",
};

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

export const isFirebaseConfigured = (): boolean => {
  return Boolean(
    firebaseConfig.apiKey &&
    firebaseConfig.projectId &&
    firebaseConfig.apiKey.length > 5 &&
    !firebaseConfig.apiKey.includes('MY_')
  );
};

export const initFirebase = () => {
  if (isFirebaseConfigured()) {
    try {
      if (!getApps().length) {
        app = initializeApp(firebaseConfig);
      } else {
        app = getApps()[0];
      }
      auth = getAuth(app);
      db = getFirestore(app);
      console.log('[RentMyShop] Firebase initialized successfully with project:', firebaseConfig.projectId);
    } catch (err) {
      console.warn('[RentMyShop] Firebase init warning:', err);
    }
  } else {
    console.info('[RentMyShop] Firebase credentials not yet detected in .env. Running in production-ready presentation mode with local persistence.');
  }

  return { app, auth, db };
};

// Initialize on module load safely
const instances = initFirebase();
export const firebaseAppInstance = instances.app;
export const firebaseAuthInstance = instances.auth;
export const firestoreInstance = instances.db;

/**
 * RentMyShop Production-Grade Firestore Security Rules
 * Prepared for Firebase deployment
 */
export const FIRESTORE_RULES = `
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Helper functions
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function isOwner(userId) {
      return isAuthenticated() && request.auth.uid == userId;
    }
    
    function isAdmin() {
      return isAuthenticated() && 
        (request.auth.token.role == 'admin' || 
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin');
    }

    // Users Collection
    match /users/{userId} {
      allow read: if isAuthenticated();
      allow create: if isOwner(userId);
      allow update: if isOwner(userId) && 
        !request.resource.data.diff(resource.data).affectedKeys().hasAny(['role', 'uid', 'createdAt']);
      allow delete: if isOwner(userId) || isAdmin();
    }

    // Shops / Properties Collection
    match /shops/{shopId} {
      allow read: if resource.data.isDeleted == false && (resource.data.status == 'active' || resource.data.ownerId == request.auth.uid || isAdmin());
      allow create: if isAuthenticated() && request.resource.data.ownerId == request.auth.uid;
      allow update: if isAuthenticated() && (resource.data.ownerId == request.auth.uid || isAdmin()) &&
        !request.resource.data.diff(resource.data).affectedKeys().hasAny(['ownerId', 'createdAt']);
      allow delete: if isAdmin() || (isAuthenticated() && resource.data.ownerId == request.auth.uid);
    }

    // Favorites Collection (userId_shopId)
    match /favorites/{favoriteId} {
      allow read: if isAuthenticated();
      allow create, delete: if isAuthenticated() && request.resource.data.userId == request.auth.uid;
    }

    // Conversations Collection
    match /conversations/{conversationId} {
      allow read, update: if isAuthenticated() && request.auth.uid in resource.data.participants;
      allow create: if isAuthenticated() && request.auth.uid in request.resource.data.participants;
    }

    // Messages Collection
    match /messages/{messageId} {
      allow read: if isAuthenticated() && 
        (resource.data.senderId == request.auth.uid || resource.data.receiverId == request.auth.uid || isAdmin());
      allow create: if isAuthenticated() && request.resource.data.senderId == request.auth.uid;
      allow update: if isAuthenticated() && (resource.data.receiverId == request.auth.uid || resource.data.senderId == request.auth.uid);
    }

    // Notifications Collection
    match /notifications/{notificationId} {
      allow read, update: if isAuthenticated() && resource.data.receiverId == request.auth.uid;
      allow create: if isAuthenticated();
    }

    // Reports Collection
    match /reports/{reportId} {
      allow create: if isAuthenticated() && request.resource.data.reporterId == request.auth.uid;
      allow read, update, delete: if isAdmin();
    }

    // Categories Collection
    match /categories/{categoryId} {
      allow read: if true;
      allow write: if isAdmin();
    }
  }
}
`;