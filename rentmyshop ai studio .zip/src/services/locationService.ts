/**
 * RentMyShop Location & Google Maps Service
 * Manages device geolocation, coordinate resolution, and Google Maps deep-links
 */

export interface LocationCoordinates {
  latitude: number;
  longitude: number;
  city?: string;
  address?: string;
}

export const POPULAR_COMMERCIAL_CITIES = [
  { city: 'New York', state: 'NY', lat: 40.7128, lng: -74.0060 },
  { city: 'San Francisco', state: 'CA', lat: 37.7749, lng: -122.4194 },
  { city: 'Chicago', state: 'IL', lat: 41.8781, lng: -87.6298 },
  { city: 'Austin', state: 'TX', lat: 30.2672, lng: -97.7431 },
  { city: 'Dubai', state: 'UAE', lat: 25.2048, lng: 55.2708 },
  { city: 'London', state: 'UK', lat: 51.5074, lng: -0.1278 },
];

export class LocationService {
  /**
   * Requests device GPS coordinates with permission handling
   */
  public static async getCurrentLocation(): Promise<LocationCoordinates> {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by your browser/device.'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;

          // Attempt basic reverse geocoding via OpenStreetMap Nominatim for accuracy without requiring immediate Google API key
          let city = 'Current Location';
          let address = `${lat.toFixed(4)}, ${lng.toFixed(4)}`;

          try {
            const res = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=14&addressdetails=1`,
              { headers: { 'Accept-Language': 'en' } }
            );
            if (res.ok) {
              const data = await res.json();
              if (data.address) {
                city = data.address.city || data.address.town || data.address.suburb || data.address.county || 'Metro Area';
                address = data.display_name?.split(',').slice(0, 3).join(',') || address;
              }
            }
          } catch {
            // Quietly retain fallback coordinates
          }

          resolve({
            latitude: lat,
            longitude: lng,
            city,
            address,
          });
        },
        (error) => {
          console.warn('[RentMyShop] Geolocation error:', error.message);
          // Default to high-profile commercial hub
          resolve({
            latitude: 40.7128,
            longitude: -74.0060,
            city: 'New York',
            address: 'Broadway & 5th Ave, Manhattan, NY',
          });
        },
        { timeout: 8000, enableHighAccuracy: true }
      );
    });
  }

  /**
   * Generates Google Maps web link to open in Google Maps app or browser
   */
  public static getGoogleMapsUrl(latitude: number, longitude: number, title?: string): string {
    const encodedQuery = encodeURIComponent(title ? `${title}, ${latitude},${longitude}` : `${latitude},${longitude}`);
    return `https://www.google.com/maps/search/?api=1&query=${encodedQuery}`;
  }

  /**
   * Calculates distance between two coordinates in kilometers
   */
  public static calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Earth radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Number((R * c).toFixed(1));
  }
}
