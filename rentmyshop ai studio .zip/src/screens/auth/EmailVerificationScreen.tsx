/**
 * RentMyShop Email Verification Screen
 * Enforces email verification before entering the commercial marketplace
 */

import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  MailCheck, 
  RotateCw, 
  LogOut, 
  Send, 
  CheckCircle2,
  ShieldAlert
} from 'lucide-react';

interface EmailVerificationScreenProps {
  onVerified: () => void;
}

export const EmailVerificationScreen: React.FC<EmailVerificationScreenProps> = ({ onVerified }) => {
  const { currentUser, checkEmailVerification, resendVerificationEmail, logout, isLoading } = useAuth();
  const [resendStatus, setResendStatus] = useState<string | null>(null);

  const handleCheck = async () => {
    const verified = await checkEmailVerification();
    if (verified) {
      onVerified();
    }
  };

  const handleResend = async () => {
    await resendVerificationEmail();
    setResendStatus('Verification email resent successfully! Check your inbox.');
    setTimeout(() => setResendStatus(null), 4000);
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-10 px-6 sm:px-10 rounded-[28px] border border-slate-100 shadow-xl shadow-slate-200/50 text-center">
          {/* Email verification illustration */}
          <div className="w-20 h-20 rounded-full bg-[#FFF5EE] text-[#FF6B00] flex items-center justify-center mx-auto mb-6 ring-8 ring-[#FFF5EE]/60">
            <MailCheck className="w-10 h-10 stroke-[2]" />
          </div>

          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mb-2">
            Verify Your Email
          </h2>

          <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto mb-6">
            We have sent an authentication link to{' '}
            <span className="font-bold text-slate-800">{currentUser?.email}</span>.
            Please verify your email address to access the commercial property marketplace.
          </p>

          <div className="p-3.5 bg-amber-50 rounded-[14px] border border-amber-200 mb-6 flex items-center gap-2.5 text-left text-xs text-amber-800 font-medium">
            <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
            <span>Unverified accounts cannot list properties or start conversations.</span>
          </div>

          {resendStatus && (
            <div className="mb-5 p-3 rounded-[14px] bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{resendStatus}</span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-3">
            <button
              onClick={handleCheck}
              disabled={isLoading}
              className="w-full py-3.5 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#FF6B00]/25 active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-60"
            >
              <RotateCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              <span>Check Verification Status</span>
            </button>

            <button
              onClick={handleResend}
              disabled={isLoading}
              className="w-full py-3 rounded-[14px] bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Resend Verification Email</span>
            </button>

            <button
              onClick={logout}
              className="w-full py-2.5 text-xs font-semibold text-slate-400 hover:text-rose-600 transition-colors flex items-center justify-center gap-1.5 pt-2"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out & Return Later</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
