/**
 * RentMyShop Forgot Password Screen
 * Clean email reset with professional confirmation modal/state
 */

import React, { useState } from 'react';
import { 
  Store, 
  Mail, 
  ArrowLeft, 
  Send, 
  CheckCircle2 
} from 'lucide-react';

interface ForgotPasswordScreenProps {
  onBackToLogin: () => void;
}

export const ForgotPasswordScreen: React.FC<ForgotPasswordScreenProps> = ({ onBackToLogin }) => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 700));
    setIsLoading(false);
    setIsSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="w-16 h-16 rounded-[20px] bg-[#FF6B00] text-white flex items-center justify-center mx-auto shadow-xl shadow-[#FF6B00]/30 ring-4 ring-[#FF6B00]/10 mb-4">
          <Store className="w-8 h-8 stroke-[2.2]" />
        </div>

        <h2 className="text-center text-2xl font-extrabold text-slate-900 tracking-tight">
          Reset Password
        </h2>
        <p className="mt-1.5 text-center text-xs text-slate-500 font-medium">
          Enter your email to receive recovery instructions
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 sm:px-10 rounded-[24px] border border-slate-100 shadow-xl shadow-slate-200/50">
          {isSubmitted ? (
            <div className="text-center py-4 space-y-4 animate-in fade-in zoom-in-95">
              <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Reset Email Dispatched</h3>
              <p className="text-xs text-slate-500 leading-relaxed max-w-xs mx-auto">
                We sent password recovery instructions to{' '}
                <span className="font-bold text-slate-800">{email}</span>. Please check your inbox and spam folder.
              </p>
              <button
                onClick={onBackToLogin}
                className="w-full py-3 rounded-[14px] bg-[#FF6B00] text-white text-xs font-bold uppercase tracking-wider shadow-md hover:bg-[#E55F00] transition-colors mt-4"
              >
                Return to Sign In
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                  Account Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="investor@commercial.com"
                    className="w-full pl-10 pr-3.5 py-3 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 placeholder-slate-400 focus:bg-white focus:border-[#FF6B00] outline-hidden transition-all"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#FF6B00]/25 active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-60"
                >
                  {isLoading ? (
                    <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Send Recovery Link</span>
                      <Send className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={onBackToLogin}
                  className="text-xs font-bold text-slate-500 hover:text-slate-800 transition-colors inline-flex items-center gap-1.5"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Sign In</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
