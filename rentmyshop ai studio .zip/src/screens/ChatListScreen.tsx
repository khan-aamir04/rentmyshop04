/**
 * RentMyShop In-App Chat List Screen
 * Displays active conversations with commercial owners, latest message, unread indicators
 */

import React, { useState } from 'react';
import { useChat } from '../context/ChatContext';
import { useAuth } from '../context/AuthContext';
import { ConversationModel } from '../types';
import { Search, MessageSquare, Store, ArrowRight } from 'lucide-react';

interface ChatListScreenProps {
  onOpenConversation: (conversationId: string) => void;
  onNavigateToExplore: () => void;
}

export const ChatListScreen: React.FC<ChatListScreenProps> = ({
  onOpenConversation,
  onNavigateToExplore,
}) => {
  const { conversations } = useChat();
  const { currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = conversations.filter((c) => {
    const query = searchQuery.toLowerCase();
    const title = (c.shopTitle || c.propertyTitle || '').toLowerCase();
    const names = c.participantNames ? Object.values(c.participantNames).join(' ').toLowerCase() : '';
    return title.includes(query) || names.includes(query);
  });

  const formatTime = (timeStr?: string) => {
    if (!timeStr) return '';
    return timeStr;
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-28 pt-4 px-4 max-w-3xl mx-auto space-y-4 animate-in fade-in duration-300">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
          Commercial Messages
        </h1>
        <p className="text-xs text-slate-500 font-medium">
          Direct, private communications with commercial property partners
        </p>
      </div>

      {/* Search Conversations */}
      <div className="relative flex items-center bg-white rounded-[14px] px-3.5 py-2.5 border border-slate-200 shadow-xs focus-within:border-[#FF6B00]">
        <Search className="w-4 h-4 text-slate-400 mr-2 shrink-0" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by partner or property title..."
          className="w-full bg-transparent text-xs font-semibold text-slate-800 placeholder-slate-400 outline-hidden"
        />
      </div>

      {/* Conversations List */}
      {filtered.length > 0 ? (
        <div className="bg-white rounded-[24px] border border-slate-100 shadow-xs divide-y divide-slate-100 overflow-hidden">
          {filtered.map((conv) => {
            // Find other participant
            const otherId = conv.participants.find((p) => p !== currentUser?.uid) || '';
            const otherName = (conv.participantNames && conv.participantNames[otherId]) || 'Commercial Partner';
            const otherImage = (conv.participantAvatars && conv.participantAvatars[otherId]) ||
              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200';
            const unread = conv.unreadCount || 0;
            const pTitle = conv.shopTitle || conv.propertyTitle || 'Commercial Listing';

            return (
              <div
                key={conv.id}
                onClick={() => onOpenConversation(conv.id)}
                className="p-4 flex items-center gap-3.5 hover:bg-slate-50 cursor-pointer transition-colors"
              >
                {/* Avatar with unread dot indicator */}
                <div className="relative shrink-0">
                  <div className="w-13 h-13 rounded-full overflow-hidden bg-slate-100 ring-2 ring-slate-100">
                    <img
                      src={otherImage}
                      alt={otherName}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {unread > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-[#FF6B00] text-white text-[9px] font-extrabold flex items-center justify-center ring-2 ring-white">
                      {unread}
                    </span>
                  )}
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="text-sm font-bold text-slate-900 truncate">
                      {otherName}
                    </h3>
                    <span className="text-[10px] font-semibold text-slate-400">
                      {formatTime(conv.lastMessageTime || conv.lastMessageTimestamp)}
                    </span>
                  </div>

                  {/* Property mini ribbon */}
                  <div className="flex items-center gap-1 text-[11px] font-bold text-[#FF6B00] mb-1 truncate">
                    <Store className="w-3 h-3 shrink-0" />
                    <span className="truncate">{pTitle}</span>
                  </div>

                  {/* Last Message preview */}
                  <p className="text-xs text-slate-500 truncate font-medium">
                    {conv.lastMessage || 'Started conversation'}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Empty State */
        <div className="bg-white rounded-[24px] border border-slate-100 p-8 text-center space-y-4 shadow-xs">
          <div className="w-14 h-14 rounded-full bg-[#FFF5EE] text-[#FF6B00] mx-auto flex items-center justify-center">
            <MessageSquare className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-slate-900">No conversations yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              Browse verified commercial shops, offices, and plots, then tap &quot;Chat with Owner&quot; to initiate a negotiation.
            </p>
          </div>
          <button
            onClick={onNavigateToExplore}
            className="px-5 py-2.5 rounded-[12px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold inline-flex items-center gap-2 shadow-md shadow-[#FF6B00]/20 active:scale-95 transition-all"
          >
            <span>Explore Properties</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
