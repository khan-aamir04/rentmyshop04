/**
 * RentMyShop Admin Moderation Console
 * Platform overview, listings moderation (Approve, Verify, Feature, Delete),
 * user management, report resolution, and security rules inspection.
 */

import React, { useState } from 'react';
import { useProperties } from '../../context/PropertyContext';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';
import { FIRESTORE_RULES } from '../../services/firebaseConfig';
import { 
  ArrowLeft, 
  ShieldCheck, 
  Building2, 
  Users, 
  AlertTriangle, 
  Check, 
  X, 
  Star, 
  Trash2, 
  FileCode, 
  Send,
  Eye,
  CheckCircle2,
  Lock
} from 'lucide-react';

interface AdminDashboardScreenProps {
  onBack: () => void;
}

export const AdminDashboardScreen: React.FC<AdminDashboardScreenProps> = ({ onBack }) => {
  const { properties, reports, resolveReport, deleteListing, updateListingStatus } = useProperties();
  const { currentUser } = useAuth();
  const { broadcastSystemNotification } = useNotifications();

  const [activeTab, setActiveTab] = useState<'overview' | 'listings' | 'reports' | 'security'>('overview');
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastMessage, setBroadcastMessage] = useState('');
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  // Overview metrics
  const totalListings = properties.length;
  const activeListings = properties.filter((p) => p.status === 'active' && !p.isDeleted).length;
  const verifiedListings = properties.filter((p) => p.isVerified).length;
  const pendingReports = reports.filter((r) => r.status === 'pending').length;

  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMessage) return;

    broadcastSystemNotification(broadcastTitle, broadcastMessage);

    setBroadcastSuccess(true);
    setBroadcastTitle('');
    setBroadcastMessage('');
    setTimeout(() => setBroadcastSuccess(false), 3000);
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-28 pt-4 px-4 max-w-5xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Top Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-700 hover:bg-slate-50 transition-colors shadow-xs"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
                Admin Console
              </h1>
              <span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 text-[10px] font-extrabold uppercase">
                Staff Only
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Marketplace governance, listing moderation, and report resolutions
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-1">
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'listings', label: `Listings (${totalListings})` },
          { id: 'reports', label: `Reports (${pendingReports})` },
          { id: 'security', label: 'Security & Rules' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-t-[12px] text-xs font-bold transition-all border-b-2 ${
              activeTab === tab.id
                ? 'border-[#FF6B00] text-[#FF6B00] bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6 animate-in fade-in">
          {/* Key Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-[20px] border border-slate-100 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Total Properties
              </span>
              <span className="text-2xl font-extrabold text-slate-900 mt-1 block">
                {totalListings}
              </span>
            </div>

            <div className="bg-white p-5 rounded-[20px] border border-slate-100 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Active Listings
              </span>
              <span className="text-2xl font-extrabold text-emerald-600 mt-1 block">
                {activeListings}
              </span>
            </div>

            <div className="bg-white p-5 rounded-[20px] border border-slate-100 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Verified Spaces
              </span>
              <span className="text-2xl font-extrabold text-blue-600 mt-1 block">
                {verifiedListings}
              </span>
            </div>

            <div className="bg-white p-5 rounded-[20px] border border-slate-100 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Pending Reports
              </span>
              <span className="text-2xl font-extrabold text-rose-600 mt-1 block">
                {pendingReports}
              </span>
            </div>
          </div>

          {/* System Broadcast Card */}
          <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs space-y-4">
            <div className="flex items-center gap-2 text-[#FF6B00]">
              <Send className="w-5 h-5" />
              <h2 className="text-base font-extrabold text-slate-900">
                Broadcast Platform Announcement
              </h2>
            </div>
            <p className="text-xs text-slate-500">
              Send an instant system-wide notification to all commercial users on RentMyShop.
            </p>

            {broadcastSuccess && (
              <div className="p-3 bg-emerald-50 text-emerald-800 rounded-[14px] text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Announcement dispatched to all marketplace users.</span>
              </div>
            )}

            <form onSubmit={handleBroadcast} className="space-y-3">
              <input
                type="text"
                required
                value={broadcastTitle}
                onChange={(e) => setBroadcastTitle(e.target.value)}
                placeholder="Announcement Title (e.g. New Commercial Districts Added)"
                className="w-full p-3 rounded-[12px] bg-slate-50 border border-slate-200 text-xs font-semibold"
              />
              <textarea
                rows={2}
                required
                value={broadcastMessage}
                onChange={(e) => setBroadcastMessage(e.target.value)}
                placeholder="Message body describing update or maintenance notice..."
                className="w-full p-3 rounded-[12px] bg-slate-50 border border-slate-200 text-xs font-medium"
              />
              <button
                type="submit"
                className="px-5 py-2.5 rounded-[12px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold shadow-md shadow-[#FF6B00]/20 active:scale-95 transition-all flex items-center gap-2"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Dispatch Broadcast</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 2: LISTINGS MODERATION */}
      {activeTab === 'listings' && (
        <div className="bg-white rounded-[24px] border border-slate-100 shadow-xs divide-y divide-slate-100 overflow-hidden animate-in fade-in">
          {properties.map((p) => (
            <div key={p.id} className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <img
                  src={p.thumbnail || p.images[0]}
                  alt={p.title}
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 rounded-[12px] object-cover bg-slate-100 shrink-0"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{p.title}</span>
                    {p.isVerified && (
                      <span className="text-[10px] font-bold bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded-sm">
                        Verified
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500">{p.city} • ${p.price.toLocaleString()} • Owner: {p.ownerName}</p>
                  <span className="text-[10px] font-bold uppercase text-slate-400">Status: {p.status}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center">
                <button
                  onClick={() => updateListingStatus(p.id, p.status === 'active' ? 'paused' : 'active')}
                  className="px-3 py-1.5 rounded-[10px] bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700 transition-colors"
                >
                  {p.status === 'active' ? 'Pause' : 'Activate'}
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Permanently remove "${p.title}"?`)) {
                      deleteListing(p.id);
                    }
                  }}
                  className="p-2 rounded-[10px] bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors"
                  title="Delete Listing"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: REPORTS RESOLUTION */}
      {activeTab === 'reports' && (
        <div className="space-y-4 animate-in fade-in">
          {reports.length > 0 ? (
            <div className="space-y-3">
              {reports.map((report) => (
                <div
                  key={report.id}
                  className="bg-white p-5 rounded-[20px] border border-slate-100 shadow-xs flex flex-col sm:flex-row justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-500" />
                      <span className="text-xs font-bold text-rose-600 uppercase tracking-wider">
                        {report.reason}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          report.status === 'resolved'
                            ? 'bg-emerald-100 text-emerald-700'
                            : 'bg-amber-100 text-amber-700'
                        }`}
                      >
                        {report.status}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900">
                      Listing: {report.shopTitle || report.propertyTitle}
                    </h3>
                    <p className="text-xs text-slate-600 italic">
                      &quot;{report.description || report.details}&quot;
                    </p>
                    <span className="text-[10px] text-slate-400 font-semibold block pt-1">
                      Reported on {new Date(report.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  {report.status === 'pending' && (
                    <div className="flex items-center gap-2 self-end sm:self-center">
                      <button
                        onClick={() => resolveReport(report.id, false)}
                        className="px-3.5 py-2 rounded-[12px] bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-600"
                      >
                        Dismiss
                      </button>
                      <button
                        onClick={() => resolveReport(report.id, true)}
                        className="px-4 py-2 rounded-[12px] bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs"
                      >
                        Remove Listing & Resolve
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white p-8 rounded-[24px] text-center text-slate-400 text-xs font-semibold">
              No pending reports from commercial users.
            </div>
          )}
        </div>
      )}

      {/* TAB 4: SECURITY & FIRESTORE RULES */}
      {activeTab === 'security' && (
        <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs space-y-4 animate-in fade-in">
          <div className="flex items-center gap-2 text-slate-900">
            <Lock className="w-5 h-5 text-[#FF6B00]" />
            <h2 className="text-base font-extrabold">Active Firestore Security Rules</h2>
          </div>
          <p className="text-xs text-slate-500">
            RentMyShop enforces strict role-based access control (RBAC), preventing phone scraping, securing in-app chats, and restricting delete permissions to listing owners or administrators.
          </p>

          <pre className="p-4 rounded-[16px] bg-slate-900 text-slate-200 text-[11px] font-mono overflow-x-auto leading-relaxed max-h-96">
            {FIRESTORE_RULES}
          </pre>
        </div>
      )}
    </div>
  );
};
