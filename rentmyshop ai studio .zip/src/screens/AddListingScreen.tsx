/**
 * RentMyShop Multi-Step Add Listing Flow
 * Exactly 5 Steps: Images (min 3, max 10), Basic Info, Location, Facilities, Preview & Publish.
 * Integrated with ImageUploadService (IMGBB + Canvas compression) and LocationService.
 */

import React, { useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useProperties } from '../context/PropertyContext';
import { PropertyCategory, PropertyPurpose, FacilityType, PropertyModel } from '../types';
import { ImageUploadService } from '../services/imageUploadService';
import { LocationService, POPULAR_COMMERCIAL_CITIES } from '../services/locationService';
import { 
  ArrowLeft, 
  ArrowRight, 
  Camera, 
  Trash2, 
  Star, 
  MapPin, 
  Navigation, 
  Check, 
  AlertCircle,
  Building2,
  DollarSign,
  Maximize2,
  FileText,
  Sparkles
} from 'lucide-react';

interface AddListingScreenProps {
  onCancel: () => void;
  onSuccess: (property: PropertyModel) => void;
}

const CATEGORIES: PropertyCategory[] = [
  'Shops',
  'Offices',
  'Warehouses',
  'Commercial Plaza',
  'Kiosk',
  'Commercial Plot',
];

const FACILITIES_LIST: FacilityType[] = [
  'Parking',
  'Electricity',
  'Water',
  'Washroom',
  'Security',
  'Internet',
  'Corner',
];

const DEFAULT_IMAGES = [
  'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1567449303078-57ad995bd301?w=1200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1604014237800-1c9102c219da?w=1200&auto=format&fit=crop&q=80',
];

export const AddListingScreen: React.FC<AddListingScreenProps> = ({ onCancel, onSuccess }) => {
  const { currentUser } = useAuth();
  const { createListing, isLoading } = useProperties();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [currentStep, setCurrentStep] = useState<number>(1);
  const [error, setError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  // Form State
  const [images, setImages] = useState<string[]>(DEFAULT_IMAGES);
  const [coverIndex, setCoverIndex] = useState<number>(0);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<PropertyCategory>('Shops');
  const [purpose, setPurpose] = useState<PropertyPurpose>('rent');
  const [price, setPrice] = useState<string>('');
  const [area, setArea] = useState<string>('');

  const [address, setAddress] = useState('450 Commercial Park, Suite 200');
  const [city, setCity] = useState('New York');
  const [latitude, setLatitude] = useState(40.7128);
  const [longitude, setLongitude] = useState(-74.0060);
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);

  const [facilities, setFacilities] = useState<FacilityType[]>([
    'Parking',
    'Electricity',
    'Water',
    'Security',
  ]);

  // Step 1: Image Upload
  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    if (images.length + files.length > 10) {
      setError('Maximum 10 commercial images permitted.');
      return;
    }

    setError(null);
    setIsUploading(true);
    setUploadProgress(10);

    try {
      const newUrls: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const url = await ImageUploadService.uploadImage(file, (p) => {
          setUploadProgress(Math.round(((i + p / 100) / files.length) * 100));
        });
        newUrls.push(url);
      }
      setImages((prev) => [...prev, ...newUrls]);
    } catch (err: any) {
      setError('Error uploading images. Please check your connection.');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const removeImage = (index: number) => {
    if (images.length <= 3) {
      setError('A minimum of 3 commercial property photos is required.');
      return;
    }
    setError(null);
    setImages((prev) => prev.filter((_, i) => i !== index));
    if (coverIndex === index) {
      setCoverIndex(0);
    } else if (coverIndex > index) {
      setCoverIndex((prev) => prev - 1);
    }
  };

  // Step 3: Location
  const handleCurrentLocation = async () => {
    setIsDetectingLocation(true);
    try {
      const loc = await LocationService.getCurrentLocation();
      setLatitude(loc.latitude);
      setLongitude(loc.longitude);
      if (loc.city) setCity(loc.city);
      if (loc.address) setAddress(loc.address);
    } finally {
      setIsDetectingLocation(false);
    }
  };

  const toggleFacility = (facility: FacilityType) => {
    setFacilities((prev) =>
      prev.includes(facility) ? prev.filter((f) => f !== facility) : [...prev, facility]
    );
  };

  // Step Navigations
  const handleNextStep = () => {
    setError(null);
    if (currentStep === 1) {
      if (images.length < 3) {
        setError('Please upload at least 3 photos of this commercial space.');
        return;
      }
    } else if (currentStep === 2) {
      if (!title.trim() || title.trim().length < 5) {
        setError('Property title must be at least 5 characters long.');
        return;
      }
      if (!description.trim() || description.trim().length < 15) {
        setError('Please provide a descriptive overview (at least 15 characters).');
        return;
      }
      if (!price || Number(price) <= 0) {
        setError('Please provide a valid price amount.');
        return;
      }
      if (!area || Number(area) <= 0) {
        setError('Please provide valid commercial square footage.');
        return;
      }
    } else if (currentStep === 3) {
      if (!address.trim() || !city.trim()) {
        setError('Address and city are required.');
        return;
      }
    } else if (currentStep === 4) {
      if (facilities.length === 0) {
        setError('Please select at least 1 facility available at this commercial property.');
        return;
      }
    }
    setCurrentStep((prev) => prev + 1);
  };

  const handlePublish = async () => {
    if (!currentUser) return;

    // Order images with cover first
    const reordered = [
      images[coverIndex],
      ...images.filter((_, i) => i !== coverIndex),
    ];

    const property = await createListing({
      ownerId: currentUser.uid,
      ownerName: currentUser.fullName,
      ownerImage: currentUser.profileImage,
      title: title.trim(),
      description: description.trim(),
      purpose,
      price: Number(price),
      pricePeriod: purpose === 'rent' ? '/month' : 'total',
      category,
      address: address.trim(),
      city: city.trim(),
      latitude,
      longitude,
      area: Number(area),
      facilities,
      images: reordered,
      thumbnail: reordered[0],
      status: 'active',
    });

    onSuccess(property);
  };

  const steps = [
    { num: 1, label: 'Photos' },
    { num: 2, label: 'Details' },
    { num: 3, label: 'Location' },
    { num: 4, label: 'Facilities' },
    { num: 5, label: 'Preview' },
  ];

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-28 pt-4 px-4 max-w-2xl mx-auto">
      {/* Top Bar */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={currentStep > 1 ? () => setCurrentStep((prev) => prev - 1) : onCancel}
          className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-700 hover:bg-slate-50 transition-colors shadow-xs"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-base font-extrabold text-slate-900 tracking-tight">
          List Commercial Property
        </h1>
        <button
          onClick={onCancel}
          className="text-xs font-bold text-slate-400 hover:text-slate-700"
        >
          Cancel
        </button>
      </div>

      {/* 5-Step Progress Ribbon */}
      <div className="bg-white rounded-[20px] p-4 border border-slate-100 shadow-xs mb-6">
        <div className="flex items-center justify-between relative">
          {/* Connector Line */}
          <div className="absolute left-6 right-6 top-1/2 -translate-y-1/2 h-0.5 bg-slate-100 -z-0" />
          {steps.map((s) => {
            const isDone = currentStep > s.num;
            const isCurrent = currentStep === s.num;
            return (
              <div key={s.num} className="flex flex-col items-center gap-1.5 z-10">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all shadow-xs ${
                    isDone
                      ? 'bg-emerald-500 text-white'
                      : isCurrent
                      ? 'bg-[#FF6B00] text-white ring-4 ring-[#FF6B00]/20'
                      : 'bg-white border border-slate-200 text-slate-400'
                  }`}
                >
                  {isDone ? <Check className="w-4 h-4 stroke-[3]" /> : s.num}
                </div>
                <span
                  className={`text-[10px] font-bold ${
                    isCurrent ? 'text-[#FF6B00]' : 'text-slate-400'
                  }`}
                >
                  {s.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <div className="mb-5 p-3.5 rounded-[14px] bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-rose-700 text-xs font-semibold">
          <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* STEP 1: IMAGES */}
      {currentStep === 1 && (
        <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs space-y-5 animate-in fade-in">
          <div>
            <h2 className="text-lg font-extrabold text-slate-900">Upload Property Photos</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Minimum 3, maximum 10 high-resolution photos. Tap star to select primary cover photo.
            </p>
          </div>

          {/* Upload Button */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-[#FF6B00]/40 hover:border-[#FF6B00] bg-[#FFF5EE]/50 hover:bg-[#FFF5EE] rounded-[18px] p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all group"
          >
            <div className="w-12 h-12 rounded-full bg-[#FF6B00] text-white flex items-center justify-center mb-2 shadow-md shadow-[#FF6B00]/30 group-hover:scale-105 transition-transform">
              <Camera className="w-6 h-6" />
            </div>
            <p className="text-xs font-bold text-slate-900">Tap to upload commercial photos</p>
            <p className="text-[11px] text-slate-400 mt-0.5">JPEG, PNG, WEBP (Auto-compressed)</p>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />
          </div>

          {isUploading && (
            <div className="p-3 bg-slate-50 rounded-[14px] border border-slate-100 space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-600">
                <span>Optimizing and uploading images...</span>
                <span>{uploadProgress}%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#FF6B00] transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Thumbnails Grid */}
          <div className="grid grid-cols-3 gap-3 pt-2">
            {images.map((img, idx) => {
              const isCover = coverIndex === idx;
              return (
                <div
                  key={idx}
                  className={`relative aspect-[4/3] rounded-[14px] overflow-hidden border-2 bg-slate-100 shadow-xs group ${
                    isCover ? 'border-[#FF6B00]' : 'border-transparent'
                  }`}
                >
                  <img
                    src={img}
                    alt={`Upload ${idx + 1}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />

                  {/* Star Cover Button */}
                  <button
                    type="button"
                    onClick={() => setCoverIndex(idx)}
                    title="Set as Cover Photo"
                    className={`absolute top-1.5 left-1.5 p-1 rounded-md transition-colors ${
                      isCover
                        ? 'bg-[#FF6B00] text-white shadow-xs'
                        : 'bg-black/50 text-white/80 hover:bg-black/80'
                    }`}
                  >
                    <Star className="w-3.5 h-3.5 fill-current" />
                  </button>

                  {/* Remove Button */}
                  <button
                    type="button"
                    onClick={() => removeImage(idx)}
                    className="absolute top-1.5 right-1.5 p-1 rounded-md bg-black/60 text-white hover:bg-rose-600 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                  {isCover && (
                    <span className="absolute bottom-1.5 left-1.5 text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded-sm bg-[#FF6B00] text-white shadow-xs">
                      Cover
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* STEP 2: BASIC INFORMATION */}
      {currentStep === 2 && (
        <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs space-y-4 animate-in fade-in">
          <div>
            <h2 className="text-lg font-extrabold text-slate-900">Commercial Specifications</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Enter key commercial details, purpose, category, and pricing.
            </p>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
              Property Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Corner Retail Showroom on Main Plaza"
              className="w-full px-3.5 py-3 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 focus:bg-white focus:border-[#FF6B00] outline-hidden transition-all"
            />
          </div>

          {/* Purpose & Category */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Purpose
              </label>
              <div className="grid grid-cols-2 gap-1.5 bg-slate-100 p-1 rounded-[14px]">
                <button
                  type="button"
                  onClick={() => setPurpose('rent')}
                  className={`py-2 rounded-[10px] text-xs font-bold capitalize transition-all ${
                    purpose === 'rent'
                      ? 'bg-white text-[#FF6B00] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  For Rent
                </button>
                <button
                  type="button"
                  onClick={() => setPurpose('sale')}
                  className={`py-2 rounded-[10px] text-xs font-bold capitalize transition-all ${
                    purpose === 'sale'
                      ? 'bg-white text-emerald-600 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  For Sale
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as PropertyCategory)}
                className="w-full p-2.5 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 focus:bg-white focus:border-[#FF6B00] outline-hidden"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Price & Area */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Price ($) {purpose === 'rent' ? '/ Month' : 'Total'}
              </label>
              <div className="relative">
                <DollarSign className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="number"
                  required
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="3500"
                  className="w-full pl-9 pr-3 py-3 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 focus:bg-white focus:border-[#FF6B00] outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Area (Sq Ft)
              </label>
              <div className="relative">
                <Maximize2 className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="number"
                  required
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                  placeholder="1450"
                  className="w-full pl-9 pr-3 py-3 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 focus:bg-white focus:border-[#FF6B00] outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
              Property Description
            </label>
            <textarea
              rows={4}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe commercial attributes, electrical load, frontage, height, customer footfall, parking accessibility, and lease conditions..."
              className="w-full p-3.5 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-medium text-slate-800 focus:bg-white focus:border-[#FF6B00] outline-hidden"
            />
          </div>
        </div>
      )}

      {/* STEP 3: LOCATION */}
      {currentStep === 3 && (
        <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-extrabold text-slate-900">Commercial Location</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Pinpoint your property coordinates and street address.
              </p>
            </div>
            <button
              type="button"
              onClick={handleCurrentLocation}
              disabled={isDetectingLocation}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#FFF5EE] text-[#FF6B00] hover:bg-[#FFEDD5] text-xs font-bold transition-colors shadow-xs"
            >
              <Navigation className={`w-3.5 h-3.5 ${isDetectingLocation ? 'animate-spin' : ''}`} />
              <span>{isDetectingLocation ? 'Locating...' : 'GPS Detect'}</span>
            </button>
          </div>

          {/* Map Picker Visual Mock/Interaction */}
          <div className="relative aspect-[16/8] w-full rounded-[18px] bg-slate-100 overflow-hidden border border-slate-200 flex items-center justify-center">
            <div className="absolute inset-0 bg-[#E8EEF5] flex items-center justify-center opacity-70">
              <div className="w-full h-full bg-[radial-gradient(#94a3b8_1px,transparent_1px)] [background-size:16px_16px]" />
            </div>

            <div className="relative z-10 flex flex-col items-center gap-1 text-center p-4">
              <div className="w-10 h-10 rounded-full bg-[#FF6B00] text-white flex items-center justify-center shadow-lg shadow-[#FF6B00]/40 ring-4 ring-white">
                <MapPin className="w-5 h-5" />
              </div>
              <p className="text-xs font-bold text-slate-900 bg-white/95 px-3 py-1 rounded-full shadow-xs mt-1">
                {address}
              </p>
            </div>
          </div>

          {/* Address */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
              Street Address & Building
            </label>
            <input
              type="text"
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. 100 Main Commercial Boulevard, Suite 402"
              className="w-full px-3.5 py-3 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 focus:bg-white focus:border-[#FF6B00] outline-hidden"
            />
          </div>

          {/* City */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
              City / Commercial Hub
            </label>
            <select
              value={city}
              onChange={(e) => {
                setCity(e.target.value);
                const found = POPULAR_COMMERCIAL_CITIES.find((c) => c.city === e.target.value);
                if (found) {
                  setLatitude(found.lat);
                  setLongitude(found.lng);
                }
              }}
              className="w-full p-2.5 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 focus:bg-white focus:border-[#FF6B00] outline-hidden"
            >
              {POPULAR_COMMERCIAL_CITIES.map((c) => (
                <option key={c.city} value={c.city}>
                  {c.city}, {c.state}
                </option>
              ))}
            </select>
          </div>

          {/* Lat & Lng */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                Latitude
              </label>
              <input
                type="number"
                step="0.0001"
                value={latitude}
                onChange={(e) => setLatitude(Number(e.target.value))}
                className="w-full p-2 rounded-[12px] bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-600"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                Longitude
              </label>
              <input
                type="number"
                step="0.0001"
                value={longitude}
                onChange={(e) => setLongitude(Number(e.target.value))}
                className="w-full p-2 rounded-[12px] bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-600"
              />
            </div>
          </div>
        </div>
      )}

      {/* STEP 4: FACILITIES */}
      {currentStep === 4 && (
        <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs space-y-4 animate-in fade-in">
          <div>
            <h2 className="text-lg font-extrabold text-slate-900">Commercial Amenities & Facilities</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Select verified facilities available to tenants and visitors.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
            {FACILITIES_LIST.map((facility) => {
              const selected = facilities.includes(facility);
              return (
                <button
                  key={facility}
                  type="button"
                  onClick={() => toggleFacility(facility)}
                  className={`p-3 rounded-[16px] border text-left flex items-center justify-between transition-all ${
                    selected
                      ? 'bg-[#FFF5EE] border-[#FF6B00] text-[#FF6B00] font-bold shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-xs font-semibold">{facility}</span>
                  <div
                    className={`w-5 h-5 rounded-md flex items-center justify-center border transition-colors ${
                      selected ? 'bg-[#FF6B00] border-[#FF6B00] text-white' : 'border-slate-300 bg-white'
                    }`}
                  >
                    {selected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* STEP 5: PREVIEW & PUBLISH */}
      {currentStep === 5 && (
        <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs space-y-5 animate-in fade-in">
          <div>
            <div className="flex items-center gap-1.5 text-[#FF6B00] mb-1">
              <Sparkles className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Review Before Live Publishing</span>
            </div>
            <h2 className="text-xl font-extrabold text-slate-900">Commercial Listing Preview</h2>
          </div>

          {/* Simulated Card Preview */}
          <div className="border border-slate-200 rounded-[18px] overflow-hidden bg-white shadow-md">
            <div className="aspect-[16/9] relative bg-slate-100">
              <img
                src={images[coverIndex] || images[0]}
                alt="Preview"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <span
                className={`absolute top-3 left-3 px-2.5 py-1 text-xs font-bold uppercase rounded-full text-white ${
                  purpose === 'rent' ? 'bg-[#FF6B00]' : 'bg-emerald-600'
                }`}
              >
                For {purpose}
              </span>
            </div>

            <div className="p-4 space-y-2">
              <div className="flex items-baseline justify-between">
                <span className="text-xl font-extrabold text-slate-900">
                  ${Number(price).toLocaleString()}
                  {purpose === 'rent' && <span className="text-xs font-bold text-slate-500">/mo</span>}
                </span>
                <span className="text-xs font-bold text-[#FF6B00] bg-[#FFF5EE] px-2.5 py-0.5 rounded-full">
                  {category}
                </span>
              </div>

              <h3 className="text-base font-bold text-slate-900">{title}</h3>
              <p className="text-xs text-slate-500 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{address}, {city}</span>
              </p>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600 font-semibold">
                <span>{Number(area).toLocaleString()} sq ft</span>
                <span>{facilities.length} amenities included</span>
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-emerald-50 rounded-[14px] border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Ready for publication. Will be immediately discoverable in search & explore.</span>
          </div>
        </div>
      )}

      {/* Bottom Action Ribbon */}
      <div className="mt-6 flex items-center gap-3">
        {currentStep > 1 && (
          <button
            type="button"
            onClick={() => setCurrentStep((prev) => prev - 1)}
            className="flex-1 py-3.5 px-4 rounded-[14px] bg-white border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors"
          >
            Back
          </button>
        )}

        {currentStep < 5 ? (
          <button
            type="button"
            onClick={handleNextStep}
            className="flex-2 py-3.5 px-6 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#FF6B00]/30 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <span>Continue</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={handlePublish}
            disabled={isLoading}
            className="flex-2 py-3.5 px-6 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#FF6B00]/30 active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {isLoading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Publish Listing</span>
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};
