/**
 * RentMyShop In-App Chat Detail Screen
 * Real-time messaging between tenant/buyer and verified property owner.
 * Context-aware property banner, message bubbles, active typing indication.
 */

import React, { useState, useEffect, useRef } from 'react';
import { useChat } from '../context/ChatContext';
import { useAuth } from '../context/AuthContext';
import { MessageModel, ConversationModel } from '../types';
import { 
  ArrowLeft, 
  Send, 
  Store, 
  ExternalLink, 
  CheckCheck, 
  ShieldCheck,
  Building2
} from 'lucide-react';

interface ChatDetailScreenProps {
  conversationId: string;
  onBack: () => void;
  onViewProperty: (propertyId: string) => void;
}

export const ChatDetailScreen: React.FC<ChatDetailScreenProps> = ({
  conversationId,
  onBack,
  onViewProperty,
}) => {
  const { conversations, activeMessages, sendMessage, markAsSeen, selectConversation, isTyping } = useChat();
  const { currentUser } = useAuth();
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Sync conversation selection
  useEffect(() => {
    selectConversation(conversationId);
    markAsSeen(conversationId);
  }, [conversationId]);

  const conversation = conversations.find((c) => c.id === conversationId);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeMessages, isTyping]);

  if (!conversation) {
    return (
      <div className="p-8 text-center text-slate-500">
        <p>Conversation not found.</p>
        <button onClick={onBack} className="mt-4 text-xs font-bold text-[#FF6B00]">
          Return to messages
        </button>
      </div>
    );
  }

  const otherId = conversation.participants.find((p) => p !== currentUser?.uid) || '';
  const otherName = (conversation.participantNames && conversation.participantNames[otherId]) || 'Commercial Partner';
  const otherImage = (conversation.participantAvatars && conversation.participantAvatars[otherId]) ||
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200';

  const propertyId = conversation.shopId || conversation.propertyId || '';
  const propertyTitle = conversation.shopTitle || conversation.propertyTitle || 'Commercial Property';
  const propertyThumbnail = conversation.shopThumbnail || conversation.propertyThumbnail || 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=400';
  const propertyPrice = conversation.shopPrice || conversation.propertyPrice || 0;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    sendMessage(conversationId, inputText.trim());
    setInputText('');
  };

  return (
    <div className="flex flex-col h-screen bg-[#F8F9FA] fixed inset-0 z-50 animate-in slide-in-from-right duration-300">
      {/* 1. Top Bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between shadow-2xs">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5">
            <div className="relative">
              <img
                src={otherImage}
                alt={otherName}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-100"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-extrabold text-slate-900">{otherName}</h2>
                <ShieldCheck className="w-3.5 h-3.5 text-[#FF6B00]" />
              </div>
              <p className="text-[10px] font-semibold text-emerald-600 mt-0.5">Active now</p>
            </div>
          </div>
        </div>

        {/* View Property Link */}
        {propertyId && (
          <button
            onClick={() => onViewProperty(propertyId)}
            className="flex items-center gap-1 text-xs font-bold text-[#FF6B00] hover:bg-[#FFF5EE] px-2.5 py-1.5 rounded-full transition-colors"
          >
            <span className="hidden sm:inline">Listing Details</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* 2. Property Mini Snapshot Banner */}
      {propertyId && (
        <div 
          onClick={() => onViewProperty(propertyId)}
          className="bg-[#FFF5EE] border-b border-[#FF6B00]/20 px-4 py-2.5 flex items-center justify-between cursor-pointer hover:bg-[#FFEDD5] transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-[10px] overflow-hidden bg-slate-200 shrink-0">
              <img
                src={propertyThumbnail}
                alt={propertyTitle}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-extrabold uppercase text-[#FF6B00] bg-white px-1.5 py-0.5 rounded-sm shadow-2xs">
                  Subject Property
                </span>
              </div>
              <p className="text-xs font-bold text-slate-900 truncate max-w-[220px] sm:max-w-md">
                {propertyTitle}
              </p>
            </div>
          </div>

          <span className="text-xs font-extrabold text-[#FF6B00]">
            ${propertyPrice.toLocaleString()}
          </span>
        </div>
      )}

      {/* 3. Messages Stream */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <div className="text-center my-2">
          <span className="px-3 py-1 rounded-full bg-slate-200/80 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
            Commercial In-App Protected Channel
          </span>
        </div>

        {activeMessages.map((msg: MessageModel) => {
          const isMe = msg.senderId === currentUser?.uid;

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} max-w-[85%] sm:max-w-[75%] ${
                isMe ? 'ml-auto' : 'mr-auto'
              }`}
            >
              <div
                className={`px-4 py-2.5 rounded-[18px] text-xs leading-relaxed font-medium shadow-2xs ${
                  isMe
                    ? 'bg-[#FF6B00] text-white rounded-tr-xs'
                    : 'bg-white text-slate-800 border border-slate-100 rounded-tl-xs'
                }`}
              >
                {msg.message || msg.text}
              </div>

              <div className="flex items-center gap-1 mt-1 px-1">
                <span className="text-[9px] text-slate-400 font-medium">
                  {msg.timestamp || 'Just now'}
                </span>
                {isMe && (
                  <CheckCheck className={`w-3 h-3 ${msg.seen ? 'text-[#FF6B00]' : 'text-slate-300'}`} />
                )}
              </div>
            </div>
          );
        })}

        {isTyping && (
          <div className="flex items-center gap-2 text-slate-400 text-xs italic">
            <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce" />
            <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce [animation-delay:0.2s]" />
            <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce [animation-delay:0.4s]" />
            <span className="text-[11px] font-semibold">{otherName} is typing...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 4. Chat Input Bar */}
      <form
        onSubmit={handleSend}
        className="bg-white border-t border-slate-200 p-3 flex items-center gap-2 safe-area-pb"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={`Message ${otherName}...`}
          className="flex-1 bg-slate-100/90 hover:bg-slate-100 focus:bg-white border border-transparent focus:border-[#FF6B00] rounded-full px-4 py-2.5 text-xs font-medium text-slate-900 placeholder-slate-400 outline-hidden transition-all"
        />

        <button
          type="submit"
          disabled={!inputText.trim()}
          className="w-10 h-10 rounded-full bg-[#FF6B00] text-white flex items-center justify-center disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#E55F00] active:scale-95 transition-all shadow-md shadow-[#FF6B00]/25 shrink-0"
        >
          <Send className="w-4 h-4 ml-0.5" />
        </button>
      </form>
    </div>
  );
};
