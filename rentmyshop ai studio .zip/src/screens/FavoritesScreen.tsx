/**
 * RentMyShop Favorites Screen
 * Displays bookmarked commercial properties with quick removal and exploration
 */

import React from 'react';
import { useProperties } from '../context/PropertyContext';
import { PropertyModel } from '../types';
import { PropertyCard } from '../components/common/PropertyCard';
import { EmptyState } from '../components/common/EmptyState';
import { Heart } from 'lucide-react';

interface FavoritesScreenProps {
  onSelectProperty: (property: PropertyModel) => void;
  onNavigateToExplore: () => void;
}

export const FavoritesScreen: React.FC<FavoritesScreenProps> = ({
  onSelectProperty,
  onNavigateToExplore,
}) => {
  const { favoriteProperties } = useProperties();

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-28 pt-4 px-4 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
          Saved Properties
        </h1>
        <p className="text-xs text-slate-500 font-medium">
          Quickly review bookmarked commercial spaces, price comparisons, and locations
        </p>
      </div>

      {favoriteProperties.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {favoriteProperties.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              onClick={onSelectProperty}
            />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Heart}
          title="No saved commercial spaces"
          description="Bookmark high-potential retail spaces, executive offices, and commercial plots while browsing to track them here."
          actionLabel="Explore Spaces"
          onAction={onNavigateToExplore}
        />
      )}
    </div>
  );
};
