/**
 * RentMyShop Notifications Screen
 * Listing inquiries, verification alerts, and system notices
 */

import React from 'react';
import { useNotifications } from '../context/NotificationContext';
import { 
  Bell, 
  CheckCheck, 
  MessageSquare, 
  ShieldCheck, 
  CheckCircle, 
  AlertCircle,
  Clock
} from 'lucide-react';
import { EmptyState } from '../components/common/EmptyState';

interface NotificationsScreenProps {
  onSelectProperty?: (propertyId: string) => void;
  onOpenChat?: (conversationId: string) => void;
}

export const NotificationsScreen: React.FC<NotificationsScreenProps> = ({
  onSelectProperty,
  onOpenChat,
}) => {
  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications();

  const getIcon = (type: string) => {
    switch (type) {
      case 'inquiry':
        return <MessageSquare className="w-4 h-4 text-[#FF6B00]" />;
      case 'verification':
        return <ShieldCheck className="w-4 h-4 text-emerald-600" />;
      case 'approval':
        return <CheckCircle className="w-4 h-4 text-blue-600" />;
      default:
        return <Bell className="w-4 h-4 text-slate-500" />;
    }
  };

  const handleClick = (notif: any) => {
    markAsRead(notif.id);
    if (notif.data?.conversationId && onOpenChat) {
      onOpenChat(notif.data.conversationId);
    } else if (notif.data?.propertyId && onSelectProperty) {
      onSelectProperty(notif.data.propertyId);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-28 pt-4 px-4 max-w-2xl mx-auto space-y-4 animate-in fade-in duration-300">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Notifications
          </h1>
          <p className="text-xs text-slate-500 font-medium">
            Commercial updates, tenant inquiries, and status notices
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={markAllAsRead}
            className="flex items-center gap-1 text-xs font-bold text-[#FF6B00] hover:underline"
          >
            <CheckCheck className="w-3.5 h-3.5" />
            <span>Mark all read</span>
          </button>
        )}
      </div>

      {notifications.length > 0 ? (
        <div className="bg-white rounded-[24px] border border-slate-100 shadow-xs divide-y divide-slate-100 overflow-hidden">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              onClick={() => handleClick(notif)}
              className={`p-4 flex items-start gap-3.5 hover:bg-slate-50 cursor-pointer transition-colors ${
                !notif.isRead ? 'bg-[#FFF5EE]/30' : ''
              }`}
            >
              <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
                {getIcon(notif.type)}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2 mb-0.5">
                  <h3 className={`text-xs sm:text-sm ${notif.isRead ? 'font-semibold text-slate-800' : 'font-bold text-slate-900'}`}>
                    {notif.title}
                  </h3>
                  <span className="text-[10px] font-semibold text-slate-400 shrink-0">
                    {notif.createdAt}
                  </span>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed font-normal">
                  {notif.body || notif.message}
                </p>
              </div>

              {!notif.isRead && (
                <span className="w-2.5 h-2.5 rounded-full bg-[#FF6B00] shrink-0 mt-1.5" />
              )}
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Bell}
          title="No notifications yet"
          description="You will receive alerts here when tenants inquire about your listings or when marketplace updates occur."
        />
      )}
    </div>
  );
};
