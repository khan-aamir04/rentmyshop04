/**
 * RentMyShop Onboarding Screens (4 Steps)
 * High-quality commercial imagery, clear hierarchy, progress indicators, Skip, Next & Get Started
 */

import React, { useState } from 'react';
import { ArrowRight, ChevronRight, Check } from 'lucide-react';

interface OnboardingScreenProps {
  onComplete: () => void;
}

const ONBOARDING_SLIDES = [
  {
    step: 1,
    title: 'Find Commercial Spaces Easily',
    subtitle: 'Discover high-yield retail shops, executive corporate offices, industrial warehouses, and commercial plots for lease or sale.',
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1000&auto=format&fit=crop&q=80',
    tag: 'EXPLORE & DISCOVER',
  },
  {
    step: 2,
    title: 'List Your Commercial Property',
    subtitle: 'Reach thousands of qualified business owners, corporate tenants, and commercial investors directly with effortless listing tools.',
    image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1000&auto=format&fit=crop&q=80',
    tag: 'INSTANT LISTINGS',
  },
  {
    step: 3,
    title: 'Secure In-App Chat',
    subtitle: 'Negotiate terms and finalize commercial agreements securely inside RentMyShop without sharing private phone numbers.',
    image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=1000&auto=format&fit=crop&q=80',
    tag: 'PRIVATE COMMUNICATION',
  },
  {
    step: 4,
    title: 'Trusted Commercial Marketplace',
    subtitle: 'One unified, verified commercial platform designed for property owners and entrepreneurs to scale their businesses.',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1000&auto=format&fit=crop&q=80',
    tag: 'VERIFIED PLATFORM',
  },
];

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const handleNext = () => {
    if (currentSlide < ONBOARDING_SLIDES.length - 1) {
      setCurrentSlide((prev) => prev + 1);
    } else {
      onComplete();
    }
  };

  const slide = ONBOARDING_SLIDES[currentSlide];

  return (
    <div className="fixed inset-0 z-50 bg-white flex flex-col justify-between overflow-hidden select-none">
      {/* Top Bar: Brand & Skip */}
      <div className="pt-6 px-6 flex items-center justify-between z-20">
        <span className="text-lg font-extrabold text-slate-900 tracking-tight">
          Rent<span className="text-[#FF6B00]">My</span>Shop
        </span>
        {currentSlide < ONBOARDING_SLIDES.length - 1 && (
          <button
            onClick={onComplete}
            className="text-xs font-bold text-slate-400 hover:text-slate-800 transition-colors uppercase tracking-wider py-1 px-2"
          >
            Skip
          </button>
        )}
      </div>

      {/* Center Image Showcase */}
      <div className="relative flex-1 flex items-center justify-center p-6 my-2">
        <div className="relative w-full max-w-sm aspect-[4/3] rounded-[24px] overflow-hidden shadow-2xl border border-slate-100 ring-8 ring-slate-50">
          <img
            src={slide.image}
            alt={slide.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover transition-all duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-3 left-4">
            <span className="px-3 py-1 rounded-full bg-black/60 backdrop-blur-md text-[10px] font-extrabold text-white tracking-wider uppercase">
              {slide.tag}
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Content & Controls */}
      <div className="p-6 bg-slate-50/70 border-t border-slate-100 rounded-t-[32px] flex flex-col gap-6">
        <div className="space-y-2 text-center max-w-sm mx-auto">
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight leading-snug">
            {slide.title}
          </h2>
          <p className="text-xs text-slate-500 leading-relaxed">
            {slide.subtitle}
          </p>
        </div>

        {/* Step Dots Indicator */}
        <div className="flex items-center justify-center gap-2">
          {ONBOARDING_SLIDES.map((_, idx) => (
            <div
              key={idx}
              className={`h-2 rounded-full transition-all duration-300 ${
                currentSlide === idx ? 'w-8 bg-[#FF6B00]' : 'w-2 bg-slate-200'
              }`}
            />
          ))}
        </div>

        {/* Action Button */}
        <div className="max-w-sm mx-auto w-full">
          <button
            onClick={handleNext}
            className="w-full py-3.5 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-sm font-bold shadow-lg shadow-[#FF6B00]/30 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            {currentSlide === ONBOARDING_SLIDES.length - 1 ? (
              <>
                <span>Get Started</span>
                <Check className="w-4 h-4 stroke-[3]" />
              </>
            ) : (
              <>
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
